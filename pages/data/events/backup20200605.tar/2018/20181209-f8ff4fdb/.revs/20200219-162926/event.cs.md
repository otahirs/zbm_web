---
taxonomy:
    skupina:
        - dorost
type: T
start: '2018-12-09'
end: '2018-12-09'
title: 'Běh na Býčí skálu'
place: 'Řečkovice, Zamilovaný háj'
meetTime: '9:30'
meetPlace: 'šatny FK Řečkovice'
startTime: '10:00'
transport: 'autobusem 42, 70 na zastávku Letovická'
id: 20181209-f8ff4fdb
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
