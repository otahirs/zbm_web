---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: T
start: '2018-11-24'
end: '2018-11-24'
title: 'Výprava Pulců a mapový trénink žáků'
place: Řečkovice
meetTime: '9:30'
meetPlace: 'na zastávce autobusu 41, 71 Žilkova'
map: 'Velká Baba (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 41, 71 na zastávku Žilkova'
return: '12:00'
id: 20181124-53c33fd0
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
