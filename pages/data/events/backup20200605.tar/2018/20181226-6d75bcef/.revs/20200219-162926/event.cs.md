---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2018-12-26'
end: '2018-12-26'
title: 'Brněnský běžecký pohár (4. závod)'
place: Syrovice
meetTime: '9:00'
meetPlace: 'Syrovce, sokolovna'
startTime: '10:30 / 11:15'
transport: individuálně
id: 20181226-6d75bcef
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
