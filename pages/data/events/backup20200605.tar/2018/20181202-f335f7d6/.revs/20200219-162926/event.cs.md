---
taxonomy:
    skupina: {  }
type: S
start: '2018-12-02'
end: '2018-12-08'
title: 'Soustředění Krkonoše - Dvorská bouda'
place: 'Dvorská bouda'
meetTime: '14:00'
accomodation: 'Dvorská bouda – http://www.dvorska-bouda.cz/'
food: 'plná penze'
return: 'v sobotu v podvečerních hodinách'
price: 'žáci  2 300,– Kč licence A + B<br> dorost  2 600,– Kč licence A<br> ostatní   3 000,– Kč<br>žáci  2 300,– Kč licence A + B<br> dorost  2 600,– Kč licence A<br> ostatní   3 000,– Kč<br>žáci  2 300,– Kč licence A + B<br> dorost  2 600,– Kč licence A<br> ostatní   3 000,– Kč'
program: 'lyžování podle sněhových podmínek'
thingsToTake: 'maratonky a orientky (pokud sníh nebude) nebo lyže (pokud sníh bude), věci co <br> běžně potřebujete<br>maratonky a orientky (pokud sníh nebude) nebo lyže (pokud sníh bude), věci co běžně potřebujete'
signups: 'do 4. listopadu 2018 přes členskou sekci'
id: 20181202-f335f7d6
template: soustredeni
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}}
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
