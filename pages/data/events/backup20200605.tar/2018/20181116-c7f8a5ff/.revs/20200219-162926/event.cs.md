---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2018-11-16'
end: '2018-11-16'
title: 'noční mapový trénink'
place: Chlébské
meetTime: '16:30'
meetPlace: 'na parkovišti u Zologické zahrady v Bystrci'
eventTypeDescription: 'krátká trať s motýlky'
map: 'Chlébské údolí (1:10 000, ekvisitance 5 m)'
transport: 'tramvají 1, 3, 11 na zastávku Zoologická zahrada'
id: 20181116-c7f8a5ff
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
