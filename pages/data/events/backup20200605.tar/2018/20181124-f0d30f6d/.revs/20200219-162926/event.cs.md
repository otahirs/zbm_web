---
taxonomy:
    skupina:
        - dorost
type: T
start: '2018-11-24'
end: '2018-11-24'
title: 'Běh s mapou z Brněnské přehrady na Babu'
place: 'Brněnská přehrada'
meetTime: '9:00'
meetPlace: 'na parkovišti v přístavišti u Brněnské přehrady'
transport: 'tramvají 1, 3, 11 zastávku Přístaviště'
note: 'sraz je v běžeckém oblečení, věci na převlečení si dáme do auta, které pak bude čekat v Řečkovicích'
id: 20181124-f0d30f6d
template: trenink
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
