---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2018-12-21'
end: '2018-12-21'
title: 'noční mapový trénink'
place: Líšeň
meetTime: '16:00'
meetPlace: 'na parkovišti nad hotelem Velká Klajdovka'
eventTypeDescription: 'scorelauf + krátká trať'
map: 'Hádecká planina (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 78 na zastávku Podbělová'
id: 20181221-e5135ccb
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
