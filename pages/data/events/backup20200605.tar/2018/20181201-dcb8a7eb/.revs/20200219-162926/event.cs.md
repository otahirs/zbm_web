---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2018-12-01'
end: '2018-12-01'
title: 'Brněnský běžecký pohár (2. závod)'
place: Okrouhlá
meetTime: '9:00'
meetPlace: 'Okrouhlá, kulturní dům'
startTime: '10:30 / 11:15'
transport: individuálně
id: 20181201-dcb8a7eb
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
