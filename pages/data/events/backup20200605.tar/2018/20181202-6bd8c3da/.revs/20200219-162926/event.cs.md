---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BZL
start: '2018-12-02'
end: '2018-12-02'
title: 'Brněnská zimní liga (1. závod)'
startTime: '14:00'
id: 20181202-6bd8c3da
template: akce
date: '2019-07-16'
---
