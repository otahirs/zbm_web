---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2018-11-17'
end: '2018-11-17'
title: 'Brněnský běžecký pohár (1. závod)'
place: Jehnice
meetTime: '9:00'
meetPlace: 'Jehnice, škola'
startTime: '10:30 / 11:15'
transport: 'autobusem 70 na zastávku Kleštínek'
id: 20181117-a0094dd8
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
