---
taxonomy:
    skupina: {  }
type: T
start: '2018-12-08'
end: '2018-12-08'
title: 'Běh s mapou Moravským krasem'
place: 'Líšeň, Velká Klajdovka'
meetTime: '9:30'
meetPlace: 'na parkovišti nad hotelem Velká Klajdovka v Líšni'
transport: 'autobusem 78 na zastávku „Podbělová“'
note: 'sraz je v běžeckém oblečení, věci na převlečení si dáme do auta'
id: 20181208-67f5d9a3
template: trenink
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
