---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2018-11-30'
end: '2018-11-30'
title: 'noční mapový trénink'
place: 'Babice nad Svitavou'
meetTime: '16:00'
meetPlace: 'na parkovišti u obchodního domu BILLA v Líšni na Novolíšeňské'
eventTypeDescription: Hagaby
map: 'Křtiny (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 8 na zastávku Novolíšeňská'
id: 20181130-005bcda1
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
