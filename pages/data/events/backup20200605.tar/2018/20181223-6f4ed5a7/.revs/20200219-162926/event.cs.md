---
taxonomy:
    skupina:
        - dorost
type: T
start: '2018-12-23'
end: '2018-12-23'
title: 'Běh okolo Brna'
place: 'Líšeň, Mariánské údolí'
meetTime: '9:00'
meetPlace: 'na končné autobusu 55 v Mariánském údolí'
transport: 'autobusem 55 na konečnou zastávku Mariánské údolí'
note: 'tradiční cca 21. ročník předvánočního oběhnutí Brna – Mariánské údolí – Pod Hádkem – Nový Dvůr – Březina – Zadní pole – Babice na d Svitavou – Alexandrovka – Adamov – Útěchov (cca 120 min'
return: 'MHD) – Soběšice – Lesná – Husovice'
id: 20181223-6f4ed5a7
template: trenink
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
