---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2018-12-07'
end: '2018-12-07'
title: 'noční mapový trénink'
place: Kuničky
meetTime: '16:00'
meetPlace: 'na parkovišti u obchodního domu LIDL na Lesné na Halasově náměstí'
eventTypeDescription: 'krátká trať'
map: 'Hálije (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 9, 11 na zastávku Halasovo náměstí'
id: 20181207-4d2c9bc6
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
