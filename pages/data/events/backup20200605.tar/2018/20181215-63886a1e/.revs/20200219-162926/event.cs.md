---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2018-12-15'
end: '2018-12-15'
title: 'Brněnský běžecký pohár (3. závod)'
place: 'Vranov u Brna'
meetTime: '9:00'
meetPlace: 'Vranov u Brna, sporotvní areál AMK Zbrojovky Brno'
startTime: '10:30 / 11:15'
transport: 'autobusem 57 na konečnou zastávku Vranov, smyčka'
id: 20181215-63886a1e
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
