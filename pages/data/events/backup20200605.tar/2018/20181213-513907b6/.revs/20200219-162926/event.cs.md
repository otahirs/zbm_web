---
taxonomy:
    skupina: {  }
type: S
start: '2018-12-13'
end: '2018-12-16'
title: 'Soustředění Sklené I'
place: 'Sklené u Fryšavy'
meetTime: '16:00'
meetPlace: 've vestibulu hlavního nádraží'
transport: 've čtvrtek 13. prosince v 16:20 vlakem z Brna hl. nádraží (sraz 16:00 ve vestibulu nádraží. Jízdenku zakoupit do stanice Žďár nad Sázavou (R 976). Ve Žďáru přestup na autobus směr Sněžné, odjezd 17:50.'
accomodation: 'Turistická základna DDM Žďár nad Sázavou Sklené – klasické místo našich soustředění. Ubytování na postelích v povlečených peřinách. WC a sprcha na pokoji.'
food: 'plná penze + svačinky. Po celý den bude k dispozici společný čaj.'
return: 'v neděli 16. prosince 15:41 (14:30) vlakem do Brna.'
price: '1 200,– Kč. V ceně je ubytování, doprava a náklady na společné jídlo. Peníze se platí přes oddílový účet a příslušné částky se objeví u každého v členské sekci.'
program: 'běhání nebo lyžování podle sněhových podmínek.'
thingsToTake: 'maratonky a orientky (pokud sníh nebude) nebo lyže (pokud sníh bude), věci co běžně potřebujete, tréninkový deník, hry na dlouhé zimní večery, dárky pod vánoční stromeček a další dle toho co Vás napadne.'
signups: 'nejpozději do 1. prosince 2018, kapacita 42 postelí'
id: 20181213-513907b6
template: soustredeni
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
