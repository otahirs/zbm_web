---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: T
start: '2018-12-22'
end: '2018-12-22'
title: 'Mapový výjezd (prosinec)'
place: Mikulov
meetTime: '9:00'
meetPlace: 'u Bohémy'
map: 'Mikulov (1:4 000, ekvidistance 2,5 m)'
transport: 'zvláštním autobusem'
food: 'oběd v restauraci v Mikulově'
leader: 'Libor Zřídkaveselý'
return: '17:00'
price: '200'
program: '2 sprintové mapové tréninky v Mikulově (pro různé skupiny kombinace – sprint, sprintové souboje, linie, koridor, krátké štafetky)'
thingsToTake: 'věci na trénink, maratonky (boty se špunty či hřeby jsou nevhodné), buzola, SI čip'
signups: 'do 9. prosince 2018 přes členskou sekci'
id: 20181222-f6026ccc
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
