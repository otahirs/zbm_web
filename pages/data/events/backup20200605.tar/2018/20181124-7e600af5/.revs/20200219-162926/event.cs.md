---
taxonomy:
    skupina:
        - dorost
type: J
start: '2018-11-24'
end: '2018-11-24'
title: O-gala
place: Plzeň
meetTime: '19:00'
note: 'vyhlášení nejlepších orientačních běžců za rok 2018 + ples – více informací na www stránkách http://kosslaviaplzen.cz/o-gala/'
id: 20181124-7e600af5
template: akce
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}}
