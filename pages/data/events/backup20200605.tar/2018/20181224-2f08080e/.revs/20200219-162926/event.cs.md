---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: T
start: '2018-12-24'
end: '2018-12-24'
title: 'Běh na Babu'
place: Medlánky
meetTime: '9:30'
meetPlace: 'Skalka za Medláneckým kopcem'
transport: 'tramvají 12 na konečnou zastávku Technologický park'
note: 'tradiční Štědrodenní výběh na Kuřimskou horu a zpět'
id: 20181224-2f08080e
template: trenink
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
