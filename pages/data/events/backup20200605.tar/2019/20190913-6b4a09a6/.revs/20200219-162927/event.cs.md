---
taxonomy:
    skupina: {  }
type: Z
start: '2019-09-13'
end: '2019-09-15'
title: 'ČPŠ + ŽA + ČPŠ - štafety + sprint + štafety (VLI + UR + VLI)'
id: 20190913-6b4a09a6
template: zavod
date: '2019-07-16'
---
