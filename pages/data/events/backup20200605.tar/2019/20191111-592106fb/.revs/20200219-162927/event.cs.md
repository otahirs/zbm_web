---
id: 20191111-592106fb
template: trenink
title: 'Pondělní mapokopce'
start: '2019-11-11'
end: '2019-11-11'
place: Rosnička
meetTime: '16:30'
meetPlace: Rosnička
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: ''
note: ''
taxonomy:
    skupina:
        1: dorost
routes:
    -
        name: 'D, D15'
        link: 'http://3drerun.worldofo.com/index.php?id=-631617&type=info'
    -
        name: 'H, H16'
        link: 'http://3drerun.worldofo.com/index.php?id=-631618&type=info'
---
* **sraz**: {{page.header.meetTime}}
