---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-12-26'
end: '2019-12-26'
title: 'BBP - Štěpánský běh Syrovice'
place: 'Syrovice, sokolovna'
meetTime: '9:30'
transport: 'auty dle domluvy'
accomodation: "\r\n\r"
template: trenink
date: '2019-11-11'
id: 20191226-e5fe3210
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
