---
taxonomy:
    skupina: {  }
type: Z
start: '2019-05-11'
end: '2019-05-12'
title: 'ČPŠ + ŽA + ČPŠ - štafety + sprint + štafety (KSU)'
id: 20190511-773a5daf
template: zavod
date: '2019-07-16'
---
