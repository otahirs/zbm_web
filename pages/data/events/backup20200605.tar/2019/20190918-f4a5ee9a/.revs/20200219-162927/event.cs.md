---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-09-18'
end: '2019-09-18'
title: 'Středeční mapový trénink (žáci-)'
place: 'Bohunice, ZŠ Arménská'
meetTime: '16:15'
meetPlace: 'před ZŠ Arménská'
eventTypeDescription: 'sprintové okruhy - sprint+linie - scorelauf+handicap'
map: 'Bohunice (1:4 000, ekvidistance 2,5 m)'
transport: 'tramvají 6, 8, 10 na zastávku Běloruská'
id: 20190918-f4a5ee9a
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
