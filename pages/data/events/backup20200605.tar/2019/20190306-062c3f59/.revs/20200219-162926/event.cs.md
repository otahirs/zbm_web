---
taxonomy:
    skupina: {  }
type: S
start: '2019-03-06'
end: '2019-03-10'
title: 'Soustředění Slovinsko'
place: Lipica
id: 20190306-062c3f59
template: soustredeni
date: '2019-07-16'
---
