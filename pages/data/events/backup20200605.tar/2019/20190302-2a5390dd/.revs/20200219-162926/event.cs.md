---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: T
start: '2019-03-02'
end: '2019-03-02'
title: 'Výprava Pulců a mapový trénink žáků'
place: Kohoutovice
meetTime: '9:30'
meetPlace: 'na zastávce trolejbusu 37 Pavlovská'
map: 'Dub Troják (1:10 000, ekvidistance 5 m)'
transport: 'trolejbusem 37 na zastávku Pavlovská'
return: '12:00'
id: 20190302-2a5390dd
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
