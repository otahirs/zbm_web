---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: T
start: '2019-01-26'
end: '2019-01-26'
title: 'Mapový výjezd (únor)'
place: 'Zahorie (SVK)'
meetTime: '8:00'
meetPlace: 'u Bohémy'
transport: 'zvláštním autobusem'
food: 'oběd v restauraci'
leader: 'Libor Zřídkaveselý'
return: '18:00'
price: '300'
program: '2 mapové tréninky'
thingsToTake: 'věci na trénink, buzola, SI čip'
signups: 'do 10. února 2019 přes členskou sekci'
id: 20190126-ed439fa8
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
