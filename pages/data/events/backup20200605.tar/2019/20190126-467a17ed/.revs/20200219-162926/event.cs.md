---
taxonomy:
    skupina:
        - pulci1
        - pulci2
type: T
start: '2019-01-26'
end: '2019-01-26'
title: 'Výprava Pulců'
place: Rosnička
meetTime: '9:30'
meetPlace: 'hala SK Brno-Žabovřesky'
map: 'Rosnička (1:4 000, ekvidistance 2,5 m)'
transport: 'tramvají 3, 11 na zastávku Burianovo náměstí nebo tramvají 1 na zastávku Bráfova'
return: '12:00'
id: 20190126-467a17ed
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
