---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-03-16'
end: '2019-03-16'
title: 'Brněnský běžecký pohár (9. závod)'
place: 'Nový Lískovec'
meetTime: '9:00'
meetPlace: 'Nový Lískovec, ZŠ Kamínky'
startTime: '10:30 / 11:15'
transport: 'trolejbusem 25, 26, 37 na zastávku Koniklecová'
id: 20190316-7ee57fd1
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
