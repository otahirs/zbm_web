---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: J
start: '2019-04-01'
end: '2019-04-01'
title: 'Změna tréninků - letní období'
id: 20190401-c09d8da2
template: akce
date: '2019-07-16'
---
