---
taxonomy:
    skupina: {  }
type: Z
start: '2019-05-18'
end: '2019-05-19'
title: 'Mistrovství ČR ve sprintu a sprintových štafetách (LPU)'
id: 20190518-fa14fadc
template: zavod
date: '2019-07-16'
---
