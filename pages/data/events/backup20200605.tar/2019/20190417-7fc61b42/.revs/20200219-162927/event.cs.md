---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-04-17'
end: '2019-04-17'
title: 'Středeční mapový trénink (žáci-)'
place: Žebětín
meetTime: '16:15'
meetPlace: 'v lese nad Žebětínem (značeno ze zastávky Ríšová)'
eventTypeDescription: 'hvězdice - okruhy - věšák-sběrák (dvojice)'
map: 'Augšperský potok (1:10 000, ekvidistance 5 m)'
transport: 'autobusem číslo 52 na zastávku Ríšova'
id: 20190417-7fc61b42
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
