---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-01-05'
end: '2019-01-05'
title: 'Brněnský běžecký pohár (5. závod)'
place: Kuřim
meetTime: '9:00'
meetPlace: 'Kuřim, ZŠ Tyršova'
startTime: '10:30 / 11:15'
transport: individuálně
id: 20190105-3e4189a5
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
