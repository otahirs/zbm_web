---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: J
start: '2019-05-13'
end: '2019-09-17'
title: 'Lékařské vyšetření'
place: 'Ústav sporotvní medecíny Brno'
transport: 'autobusem  44, 84 na zastávku „Velodrom“'
note: 'přihlášky přes členskou sekci do 28. dubna 2019'
id: 20190513-bcd54112
template: akce
date: '2019-07-16'
---
{{page.header.note}}
 Doprava {{page.header.transport}}.
