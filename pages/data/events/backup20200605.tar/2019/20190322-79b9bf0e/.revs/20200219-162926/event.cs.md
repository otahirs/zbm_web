---
taxonomy:
    skupina: {  }
type: Z
start: '2019-03-22'
end: '2019-03-24'
title: 'Jarní pohár 2019 (PHK)'
place: 'Hradec králové'
id: 20190322-79b9bf0e
template: zavod
date: '2019-07-16'
meetTime: ''
meetPlace: ''
link: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: ''
note: ''
---

