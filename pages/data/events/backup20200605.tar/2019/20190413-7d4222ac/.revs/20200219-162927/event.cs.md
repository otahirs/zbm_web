---
taxonomy:
    skupina: {  }
type: BBP
start: '2019-04-13'
end: '2019-04-13'
title: 'Brněnský běžecký pohár (10. závod)'
place: 'Brněnská přehrada'
meetTime: '9:00'
meetPlace: 'Brněnská přehrada, hotel Rakovec'
startTime: '10:30 / 11:15'
transport: 'tramvají 3, 11 na konečnou zastávku Rakovecká'
id: 20190413-7d4222ac
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
