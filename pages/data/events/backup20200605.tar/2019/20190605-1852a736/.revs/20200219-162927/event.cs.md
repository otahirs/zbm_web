---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-06-05'
end: '2019-06-05'
title: 'Středeční mapový trénink (všichni) - M Jihomoravského kraje ve sprintových štafetách'
place: Lesná
meetTime: '16:30'
meetPlace: 'na louce pod ZŠ Blažkova'
eventTypeDescription: 'sprintové štafety'
map: 'Lesná (1:4 000, ekvidistance 2,5 m)'
transport: 'tramvají 9, 11 na konečnou zastávku Čertova rokle'
id: 20190605-1852a736
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
