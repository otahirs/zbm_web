---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-01'
end: '2019-06-02'
title: 'Český pohár, ŽA (DOK + DKP)'
id: 20190601-9495bf62
template: zavod
date: '2019-07-16'
---
