---
taxonomy:
    skupina: {  }
type: Z
start: '2019-08-16'
end: '2019-08-18'
title: 'Rumcajsový míle (SJC)'
place: 'Český ráj'
id: 20190816-46bccaae
template: zavod
date: '2019-07-16'
---
