---
taxonomy:
    skupina: {  }
type: S
start: '2019-10-25'
end: '2019-10-30'
title: 'Soustředění Chorvatsko'
id: 20191025-5f9286ef
template: soustredeni
date: '2019-07-16'
---
