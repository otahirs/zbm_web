---
taxonomy:
    skupina: {  }
type: S
start: '2019-05-03'
end: '2019-05-05'
title: 'Soustředění Šumperk'
place: Šumperk
id: 20190503-de273db5
template: soustredeni
date: '2019-07-16'
---
