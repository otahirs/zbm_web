---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-05'
end: '2019-06-05'
title: 'Celostátní finále Přeboru škol'
place: 'Brno, Lesná'
meetTime: '8:00'
meetPlace: 'louka pod ZŠ Blažkova'
startTime: '11:30'
doWeOrganize: '1'
id: 20190605-e1e3362e
template: zavod
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
