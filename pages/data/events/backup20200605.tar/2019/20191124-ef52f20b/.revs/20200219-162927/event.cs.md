---
taxonomy:
    skupina:
        - dorost
type: T
start: '2019-11-24'
end: '2019-11-24'
title: 'Běh s mapou na Přehradě'
place: Přístaviště
meetTime: '9:30'
meetPlace: 'Na parkovišti u přístaviště'
transport: 'tram: 1'
template: trenink
date: '2019-11-11'
id: 20191124-ef52f20b
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
