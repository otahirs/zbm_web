---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-06-12'
end: '2019-06-12'
title: 'Středeční mapový trénink (všichni)'
place: 'Útěchov, U buku'
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'v lese nedaleko zastávky U buku'
eventTypeDescription: 'linie - scorelauf - kombotech - sudá-lichá'
map: 'U buku (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 57 na zastávku U buku'
id: 20190612-ebb6433d
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
