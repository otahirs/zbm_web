---
taxonomy:
    skupina: {  }
type: S
start: '2019-07-20'
end: '2019-07-27'
title: O-ringen
place: Norrköping
id: 20190720-0d0f38b3
template: soustredeni
date: '2019-07-16'
---
