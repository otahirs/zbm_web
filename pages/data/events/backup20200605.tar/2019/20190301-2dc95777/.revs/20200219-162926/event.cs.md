---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2019-03-01'
end: '2019-03-01'
title: 'noční mapový trénink'
place: Sentice
meetTime: '17:30'
meetPlace: 'u konečné tramvaje číslo 1 v Řečkovicích'
eventTypeDescription: 'krátká trať'
map: 'Sokolí (1:10 000, ekvidistance 5 m)'
transport: 'tramavjí 1 na konečnou zastávku Řečkovice'
id: 20190301-2dc95777
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
