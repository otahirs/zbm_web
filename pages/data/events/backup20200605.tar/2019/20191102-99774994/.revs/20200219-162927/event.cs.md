---
taxonomy:
    skupina: {  }
type: S
start: '2019-11-02'
end: '2019-11-03'
title: 'Oddílový přebor 2019'
id: 20191102-99774994
template: soustredeni
date: '2019-07-16'
---
téma: Policajti
odjezd v 8:00 od Bohémy