---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-01-26'
end: '2019-01-26'
title: 'Brněnský běžecký pohár (7. závod)'
place: Rájec
meetTime: '9:00'
meetPlace: 'Rájec, Gymnázium Rájec-Jestřebí'
startTime: '10:30 / 11:15'
transport: individuálně
id: 20190126-2bcb5450
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
