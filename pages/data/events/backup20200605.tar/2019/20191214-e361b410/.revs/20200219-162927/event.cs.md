---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-12-14'
end: '2019-12-14'
title: 'BBP - Vranovský žleb'
place: 'Vranov, motokros'
meetTime: '9:30'
transport: 'auty dle domluvy'
startTime: '11:30'
template: trenink
date: '2019-11-11'
id: 20191214-e361b410
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
