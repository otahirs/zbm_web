---
taxonomy:
    skupina:
        1: dorost
type: T
start: '2019-12-23'
end: '2019-12-23'
title: 'Běh okolo Brna'
place: 'Mariánské údolí'
meetTime: '9:00'
meetPlace: 'konečná bus: 55, Mariánské údolí'
transport: 'bus: 55'
template: trenink
date: '2019-11-11'
id: 20191223-cb92ca17
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
leader: ''
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
