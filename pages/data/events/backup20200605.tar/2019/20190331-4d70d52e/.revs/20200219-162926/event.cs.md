---
taxonomy:
    skupina: {  }
type: M
start: '2019-03-31'
end: '2019-03-31'
title: 'Mapový trénink (žáci-)'
place: Kohoutovice
meetTime: '9:30'
meetPlace: 'ZŠ Chalabalova'
map: 'Kohoutovice (1:4 000, ekvidistance 2,5 m)'
transport: 'trolejbusem 37 na zastávku Stamicova'
food: 'oběd v restauraci v Proseči'
return: '15:00'
price: '100'
id: 20190331-4d70d52e
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
