---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-03-09'
end: '2019-03-09'
title: 'Brněnský běžecký pohár (8. závod)'
place: Modřice
meetTime: '9:00'
meetPlace: 'Modřice, sokolovna'
startTime: '10:30 / 11:15'
transport: 'tramvají 2 na konečnou zastávku Modřice, smyčka'
id: 20190309-5aef6c8d
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
