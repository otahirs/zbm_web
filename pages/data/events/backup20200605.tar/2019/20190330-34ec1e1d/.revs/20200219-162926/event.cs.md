---
taxonomy:
    skupina:
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: T
start: '2019-03-30'
end: '2019-03-30'
title: 'Mapový výjezd (březen)'
place: Proseč
meetTime: '8:00'
meetPlace: 'u Bohémy'
map: 'Toulovcovy maštale (1:10 000, ekvidistance 5 m)'
transport: 'zvláštním autobusem'
food: 'oběd v restauraci v Proseči'
leader: 'Libor Zřídkaveselý'
return: '18:00'
price: '200'
program: '2 mapové tréninky'
thingsToTake: 'věci na trénink, buzola, SI čip'
signups: 'do 17. února 2019 přes členskou sekci'
id: 20190330-34ec1e1d
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
