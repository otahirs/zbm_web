---
taxonomy:
    skupina: {  }
type: Z
start: '2019-08-30'
end: '2019-09-01'
title: 'Cena východních Čech (LPU)'
place: Krasnice
id: 20190830-4b173f43
template: zavod
date: '2019-07-16'
---
