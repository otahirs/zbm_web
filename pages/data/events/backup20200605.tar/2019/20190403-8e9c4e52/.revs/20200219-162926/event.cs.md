---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-04-03'
end: '2019-04-03'
title: 'Středeční mapový trénink (všichni)'
place: Soběšice
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'v lese na silničce Soběšice - Mokrá hora (značeno ze zastávky Klarisky)'
eventTypeDescription: 'fáborkovaná linie - sudá-lichá - shluky - kombotech'
map: 'Soběšice (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 43, 57 na zastávku Klarisky'
id: 20190403-8e9c4e52
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
