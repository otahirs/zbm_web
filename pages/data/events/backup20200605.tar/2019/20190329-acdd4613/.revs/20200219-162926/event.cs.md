---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2019-03-29'
end: '2019-03-29'
title: 'noční mapový trénink'
place: Lipůvka
meetTime: '18:00'
meetPlace: 'u konečné tramvaje číslo 1 v Řečkovicích'
eventTypeDescription: 'scorelauf + krátká trať'
map: 'Kremlovsko (1:10 000, ekvidistance 5 m)'
transport: 'tramavjí 1 na konečnou zastávku Řečkovice'
id: 20190329-acdd4613
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
