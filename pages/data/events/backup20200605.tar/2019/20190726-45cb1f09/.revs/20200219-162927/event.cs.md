---
taxonomy:
    skupina: {  }
type: S
start: '2019-07-26'
end: '2019-08-04'
title: 'Soustředění Švédsko'
place: Hallsberg
id: 20190726-45cb1f09
template: soustredeni
date: '2019-07-16'
---
