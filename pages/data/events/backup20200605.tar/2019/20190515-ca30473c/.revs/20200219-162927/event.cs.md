---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-05-15'
end: '2019-05-15'
title: 'Středeční mapový trénink (žáci-)'
place: Soběšice
meetTime: '16:15'
meetPlace: 'v lese u okraje louky pod Soběšicemi'
eventTypeDescription: 'sudá-lichá - odbočovák - vrstevnicový COB'
map: 'Zamilovaný háj (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 43 na zastávku Útěchovská'
id: 20190515-ca30473c
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
