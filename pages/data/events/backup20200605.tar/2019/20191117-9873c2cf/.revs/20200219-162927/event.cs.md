---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: BBP
start: '2019-11-17'
end: '2019-11-17'
title: 'BBP - Běh o pohár Jehnic – Běh 17. listopadu'
place: 'Jehnice, ZŠ'
meetTime: '9:30'
transport: 'MHD, nebo auty dle osobní domluvy'
startTime: '10:30'
template: trenink
date: '2019-11-11'
id: 20191117-9873c2cf
meetPlace: ''
eventTypeDescription: ''
map: ''
terrain: ''
leader: ''
note: 'https://www.atletikauni.cz/cz/s2423/Serialy/Seznam-rocniku/c3117-Rocnik-serialu/atsy35'
results:
    -
        name: '10 km'
        link: 'https://www.atletikauni.cz/cz/s1526/Vysledky/Seznam-zavodu/c3108-Detail-vysledku/atr7084-Hlavni-zavod-10km'
    -
        name: '5 km'
        link: 'https://www.atletikauni.cz/cz/s1526/Vysledky/Seznam-zavodu/c3108-Detail-vysledku/atr7083-Hlavni-zavod-5km'
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
