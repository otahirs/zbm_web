---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-09-04'
end: '2019-09-04'
title: 'Středeční mapový trénink (dorost+)'
place: Lipůvka
meetTime: '16:30'
meetPlace: 'u konečné tramvaje číslo 1 v Řečkovicích'
eventTypeDescription: shluky
map: 'Petrova studánka (1:10 000, ekvidistance 5 m)'
transport: 'tramavjí 1 na konečnou zastávku Řečkovice'
id: 20190904-9edd362a
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
