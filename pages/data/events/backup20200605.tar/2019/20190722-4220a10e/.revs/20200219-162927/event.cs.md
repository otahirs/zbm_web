---
taxonomy:
    skupina: {  }
type: S
start: '2019-07-22'
end: '2019-07-28'
title: 'Soustředění 5 dnů OB'
place: Doksy
id: 20190722-4220a10e
template: soustredeni
date: '2019-07-16'
---
