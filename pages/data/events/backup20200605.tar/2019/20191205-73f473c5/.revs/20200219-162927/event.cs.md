---
taxonomy:
    skupina:
        3: zaci2
        4: dorost
type: S
start: '2019-12-05'
end: '2019-12-08'
title: 'Předvánoční Sklené'
place: Sklené
gps: '49.61037, 16.00859'
meetTime: '16:30'
meetPlace: 'https://mapy.cz/s/jacubofuco'
transport: auty
accomodation: 'Na posteli'
food: 'od páteční snídaně, vemte si s sebou večeři na čtvrtek!!!'
return: '15:00'
price: '1200 Kč'
program: 'Běh nebo lyže'
thingsToTake: 'maratonky, orientky, hry  na  zimní  večery (Spaceteam, Openttd,.. ) dárky  pod vánoční stromeček (zvykem je donést navíc jeden erární)'
signups: ''
template: soustredeni
date: '2019-11-11'
id: 20191205-73f473c5
leader: 'Jan Zháňal'
note: "**POZOR: změna místa srazu!**\r\nDoprava se řeší v [google dokumentu](https://docs.google.com/spreadsheets/d/1YinuAYm1ibCy6NifeXaW6OeX15bLgZhP4Kx4qsW4tCc/edit#gid=0)"
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
