---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-06-19'
end: '2019-06-19'
title: 'Středeční mapový trénink (žáci-)'
place: Ivanovice
meetTime: '16:15'
meetPlace: 'v sedle pod Velkou Babou'
eventTypeDescription: 'hvězdice - kombotech - I. úsek štafet'
map: 'Velká Baba (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 41 na zastávku Kouty'
id: 20190619-52bf204e
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
