---
taxonomy:
    skupina: {  }
type: Z
start: '2019-09-21'
end: '2019-09-22'
title: 'Mistrovství ČR na klasické trati (TJN)'
place: Bedřichov
id: 20190921-cc684fb9
template: zavod
date: '2019-07-16'
---
