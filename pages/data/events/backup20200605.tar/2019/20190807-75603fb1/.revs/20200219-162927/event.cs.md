---
taxonomy:
    skupina: {  }
type: Z
start: '2019-08-07'
end: '2019-08-11'
title: 'Orienteering Adventure (OAV)'
place: 'Špindlerův Mlýn'
id: 20190807-75603fb1
template: zavod
date: '2019-07-16'
---
