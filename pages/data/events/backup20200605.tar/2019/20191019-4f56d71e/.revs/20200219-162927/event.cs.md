---
taxonomy:
    skupina:
        1: dorost
type: S
start: '2019-10-19'
end: '2019-10-20'
title: 'Soustředění Rakousko'
place: 'Linz (AUT)'
id: 20191019-4f56d71e
template: soustredeni
date: '2019-07-16'
meetTime: '9:00'
meetPlace: Bohéma
transport: 'osobními auty'
leader: 'Libor Zřídkaveselý'
note: ''
return: ''
price: ''
program: ''
thingsToTake: ''
signups: ''
gps: '14.31124, 48.46109'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
