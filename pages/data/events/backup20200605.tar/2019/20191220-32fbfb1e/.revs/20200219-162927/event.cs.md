---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2019-12-20'
end: '2019-12-20'
title: 'VáNoční mapový trénink'
place: 'Brno, Myslivna'
gps: '49.18794, 16.55234'
meetTime: '16:00'
meetPlace: 'parkoviště u zastávky Myslivna'
transport: 'bus: 68'
startTime: '16:30'
eventTypeDescription: 'Hromadný start s vánočním bonusem'
map: Myslivna
template: trenink
date: '2019-11-11'
id: 20191220-32fbfb1e
terrain: ''
leader: ''
note: ''
routes:
    -
        name: H
        link: 'http://3drerun.worldofo.com/index.php?id=-636744&type=info'
    -
        name: D
        link: 'http://3drerun.worldofo.com/index.php?type=info&id=-636743'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/index.php?id=-636745&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
