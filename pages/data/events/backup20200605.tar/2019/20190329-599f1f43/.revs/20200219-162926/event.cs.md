---
taxonomy:
    skupina:
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-03-29'
end: '2019-03-29'
title: 'Mapový trénink (žáci-)'
place: 'Královo Pole'
meetTime: '16:00'
meetPlace: 'v sedle pod Medláneckým kopcem nad areálem kolejí VUT'
map: 'Kozí hora (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 53 na konečnou zastávku Kolejní'
id: 20190329-599f1f43
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
