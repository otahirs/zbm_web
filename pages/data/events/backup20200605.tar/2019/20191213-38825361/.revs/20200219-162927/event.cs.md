---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2019-12-13'
end: '2019-12-13'
title: 'noční mapový trénink'
place: Radostice
gps: '49.13376, 16.47591'
meetTime: '16:30'
meetPlace: 'STK Nový Lískovec'
transport: 'tram: 6, 8, Nový Lískovec'
startTime: '17:30'
eventTypeDescription: 'Hromadný start'
map: Okrouhlík
template: trenink
date: '2019-11-11'
id: 20191213-38825361
terrain: ''
leader: ''
note: ''
routes:
    -
        name: D
        link: 'http://3drerun.worldofo.com/?id=-636475&type=info'
    -
        name: H
        link: 'http://3drerun.worldofo.com/?id=-636476&type=info'
    -
        name: '1.rok dorost'
        link: 'http://3drerun.worldofo.com/?id=-636479&type=info'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/?id=-636481&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
