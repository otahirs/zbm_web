---
taxonomy:
    skupina:
        - dorost
type: L
start: '2019-04-25'
end: '2019-04-25'
title: 'Liga brněnských škol v orientačním běhu (3. kolo)'
place: Rosnička
meetTime: '8:00'
meetPlace: 'u haly SK Brno-Žabovřesky'
startTime: '9:30'
doWeOrganize: '1'
note: 'pořadatelé: Zhusta + dorostenci'
id: 20190425-bb1da6c5
template: akce
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
