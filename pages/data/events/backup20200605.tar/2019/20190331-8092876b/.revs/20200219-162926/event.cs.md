---
taxonomy:
    skupina: {  }
type: T
start: '2019-03-31'
end: '2019-03-31'
title: 'Běh s mapou po Holedné'
place: Kohoutovice
meetTime: '9:30'
meetPlace: 'ZŠ Chalabalova'
transport: 'trolejbusem 37 na zastávku Stamicova'
food: 'oběd v restauraci v Proseči'
return: '15:00'
price: '100'
id: 20190331-8092876b
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
