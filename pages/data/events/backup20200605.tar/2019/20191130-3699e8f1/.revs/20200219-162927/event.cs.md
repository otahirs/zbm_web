---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-11-30'
end: '2019-11-30'
title: 'BBP - Mikulášský běh Okrouhlá'
place: 'Okrouhlá, KD'
meetTime: '9:30'
transport: 'auty dle domluvy'
startTime: '10:30'
template: trenink
date: '2019-11-11'
id: 20191130-3699e8f1
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
