---
taxonomy:
    skupina:
        - dorost
type: L
start: '2019-10-01'
end: '2019-10-01'
title: 'Liga brněnských škol v orientačním běhu (2. kolo)'
place: Špilberk
meetTime: '8:00'
meetPlace: 'před hlavní bránou do hradu na konci ulice Gorazdova'
startTime: '9:30'
doWeOrganize: '1'
note: 'pořadatelé: Zhusta + dorostenci'
id: 20191001-6df49276
template: akce
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
