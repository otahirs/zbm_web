---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BZL
start: '2019-03-17'
end: '2019-03-17'
title: 'Brněnská zimní liga (5. závod)'
startTime: '14:00'
id: 20190317-5cd8dc30
template: akce
date: '2019-07-16'
---
