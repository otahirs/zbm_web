---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-06-26'
end: '2019-06-26'
title: 'Středeční mapový trénink (všichni) - M Jihomoravského kraje ve štafetách'
place: Lipůvka
meetTime: '16:30'
meetPlace: 'parkoviště u nádraží Brno - Královo Pole'
eventTypeDescription: štafety
map: 'Petrova studánka (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 6 na konečnou zastávku Královo Pole, nádraží'
id: 20190626-fa744975
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
