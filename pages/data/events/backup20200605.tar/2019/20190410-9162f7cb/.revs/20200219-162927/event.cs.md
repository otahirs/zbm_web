---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-04-10'
end: '2019-04-10'
title: 'Středeční mapový trénink (dorost+)'
place: Kuničky
meetTime: '19:00'
meetPlace: 'na parkovišti u obchodního domu LIDL na Lesné na Halasově náměstí'
eventTypeDescription: 'noční trénink'
map: 'Hálije (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 9, 11 na zastávku Halasovo náměstí'
id: 20190410-9162f7cb
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
