---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: T
start: '2019-12-15'
end: '2019-12-15'
title: 'Běh s mapou, výprava pulců'
place: 'Velká Baba'
meetTime: '9:30'
meetPlace: 'Řečkovice, Žilkova '
transport: 'bus: 41,71'
template: trenink
date: '2019-11-11'
id: 20191215-af2bbc34
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
