---
taxonomy:
    skupina:
        1: pulci2
        2: pulci1
type: BZL
start: '2019-12-01'
end: '2019-12-01'
title: 'Adamna Cup'
place: Řečkovice
template: zavod
date: '2019-11-11'
id: 20191201-2b908a68
meetTime: ''
meetPlace: ''
link: 'http://cup.adamna.net/'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: ''
note: ''
---
