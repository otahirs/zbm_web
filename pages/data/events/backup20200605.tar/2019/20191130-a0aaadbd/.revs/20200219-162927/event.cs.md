---
taxonomy:
    skupina:
        1: dorost
type: BZL
start: '2019-11-30'
end: '2019-11-30'
title: 'Vracov - COB, hromadně'
place: Vracov
gps: '49.18693, 16.62009'
meetTime: '9:00'
meetPlace: 'Parkoviště u Lidlu, Dornych'
template: zavod
date: '2019-11-11'
id: 20191130-a0aaadbd
link: 'https://oris.orientacnisporty.cz/Zavod?id=5510'
eventTypeDescription: 'T1, T2, T3, T4, T5, T6'
startTime: '11:00'
map: 'Vracovské duny'
terrain: 'Rovinatý s minimálním převýšením a s výskytem písečných dun. Většinou dobře průběžný borovicový les, místy polouzavřený prostor se smíšeným lesem a podmáčenými oblastmi.'
transport: 'auty,'
leader: Jenda
note: 'doprava v [google dokumentu](https://docs.google.com/spreadsheets/d/1zA6o1Jcc0F_uvmgz6oLd5eJ8OWvo3iOXlOqyXCdZbR0/edit?fbclid=IwAR1miroMO6irE10Qdd_2fFqp06nyUK7I1YGxaOvLMPEXAuKq-utI5W2fPec#gid=0)'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
