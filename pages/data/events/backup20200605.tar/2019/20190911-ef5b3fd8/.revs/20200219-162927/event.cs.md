---
taxonomy:
    skupina:
        1: dorost
        2: dorost
type: M
start: '2019-09-11'
end: '2019-09-11'
title: 'Středeční mapový trénink (dorost+)'
place: Bukovinka
meetTime: '16:30'
meetPlace: 'na parkovišti u BILLY v Líšni'
eventTypeDescription: 'rozložený III. úsek štafet'
map: 'Rakovecké údolí (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 8 na zastávku Novolíšeňská'
id: 20190911-ef5b3fd8
template: trenink
date: '2019-07-16'
startTime: ''
terrain: ''
leader: ''
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
