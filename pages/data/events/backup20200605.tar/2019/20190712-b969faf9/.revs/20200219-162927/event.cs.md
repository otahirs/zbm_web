---
taxonomy:
    skupina: {  }
type: Z
start: '2019-07-12'
end: '2019-07-14'
title: 'H.S.H. Vysočina cup (CHT)'
place: Svratouch
id: 20190712-b969faf9
template: zavod
date: '2019-07-16'
---
