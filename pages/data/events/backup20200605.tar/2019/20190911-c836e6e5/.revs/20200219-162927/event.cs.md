---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
type: M
start: '2019-09-11'
end: '2019-09-11'
title: 'Středeční mapový trénink (žáci-)'
place: 'Líšeň, mariánské údolí'
meetTime: '16:15'
meetPlace: 'v lese na křižovatce nedaleko elektrického vedení na reastaurací U raka'
eventTypeDescription: 'linie - scorelauf - scorelauf'
map: 'Říčky (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 55 na konečnou zastávku Mariánské údolí'
id: 20190911-c836e6e5
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
