---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-22'
end: '2019-06-23'
title: 'Mistrovství ČR na krátké trati (LTU)'
id: 20190622-9405a678
template: zavod
date: '2019-07-16'
---
