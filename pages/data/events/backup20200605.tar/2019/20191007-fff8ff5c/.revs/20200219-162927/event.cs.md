---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: J
start: '2019-10-07'
end: '2019-10-07'
title: 'Změna tréninků - odpočinkové období'
id: 20191007-fff8ff5c
template: akce
date: '2019-07-16'
---
