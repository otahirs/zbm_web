---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BZL
start: '2019-02-02'
end: '2019-02-02'
title: 'Brněnská zimní liga (3. závod)'
id: 20190202-66e6022c
template: akce
date: '2019-07-16'
---
