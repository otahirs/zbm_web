---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: T
start: '2019-01-26'
end: '2019-01-26'
title: 'Mapový výjezd (leden)'
place: 'Wien (AUT)'
meetTime: '7:00'
meetPlace: 'u Bohémy'
transport: 'osobními auty'
food: 'oběd v restauraci ve Vídni'
leader: 'Libor Zřídkaveselý'
return: '19:00'
price: '300'
program: '2 sprintové mapové tréninky v Mikulově (pro různé skupiny kombinace – sprint, sprintové souboje, linie, koridor, krátké štafetky)'
thingsToTake: 'věci na trénink, maratonky (boty se špunty či hřeby jsou nevhodné), buzola, SI čip'
signups: 'do 13. ledna 2019 přes členskou sekci'
id: 20190126-ef10745b
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **strava**: {{page.header.food}}
