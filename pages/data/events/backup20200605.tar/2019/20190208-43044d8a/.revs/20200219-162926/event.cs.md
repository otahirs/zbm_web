---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2019-02-08'
end: '2019-02-08'
title: 'noční mapový trénink'
place: 'Ochoz u Brna'
meetTime: '17:00'
meetPlace: 'na parkovišti u obchodního domu BILLA v Líšni na Novolíšeňské'
eventTypeDescription: 'krátká trať'
map: 'Zadní Hády (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 8 na zastávku Novolíšeňská'
id: 20190208-43044d8a
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
