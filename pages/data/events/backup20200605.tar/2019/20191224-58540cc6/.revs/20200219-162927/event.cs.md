---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: T
start: '2019-12-24'
end: '2019-12-24'
title: 'Vánoční běh na Babu'
place: Baba
meetTime: '9:30'
meetPlace: 'Medlánecký vrch'
transport: 'tram: 12'
template: trenink
date: '2019-11-11'
id: 20191224-58540cc6
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
leader: ''
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
