---
taxonomy:
    skupina: {  }
type: Z
start: '2019-07-24'
end: '2019-07-28'
title: 'Bohemia Orienteering 2019 (BOR)'
place: 'Nový Bor'
id: 20190724-b7ef5bb1
template: zavod
date: '2019-07-16'
---
