---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-04-24'
end: '2019-04-24'
title: 'Středeční mapový trénink (všichni)'
place: Bystrc
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'nedaleko obchodního domu PENNY MARKET v Bystrci'
eventTypeDescription: 'sprint - sprint - sprintové variace - scorelauf + handicap'
map: 'Bystrc (1:4 000, ekvidistance 2,5 m)'
transport: 'tramvají číslo 1, 3, 11 na zastávku Přístaviště'
id: 20190424-66453f70
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
