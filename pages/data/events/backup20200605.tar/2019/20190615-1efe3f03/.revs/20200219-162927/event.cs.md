---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-15'
end: '2019-06-15'
title: 'ŽB-Morava + Jihomoravská liga - klasická trať (VBM)'
id: 20190615-1efe3f03
template: zavod
date: '2019-07-16'
---
