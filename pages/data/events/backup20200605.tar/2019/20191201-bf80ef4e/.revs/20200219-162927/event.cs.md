---
taxonomy:
    skupina:
        1: dorost
type: T
start: '2019-12-01'
end: '2019-12-01'
title: 'Běh na Býčí skálu'
place: Řečkovice
gps: '49.24721, 16.58741'
meetTime: '9:00'
meetPlace: 'Šatny fotbalového stadionu,Novoměstská 1941/4'
transport: 'tram: 1'
template: trenink
date: '2019-11-11'
id: 20191201-bf80ef4e
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
leader: ''
note: 'https://mslavia.cz/akce/beh-na-byci-skalu-2019-porada/'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
