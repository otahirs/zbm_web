---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2019-01-11'
end: '2019-01-11'
title: 'noční mapový trénink'
place: Žebětín
meetTime: '16:30'
meetPlace: 'na rohu louky nad Žebětínem'
eventTypeDescription: 'krátká trať s motýlky'
map: 'Augšperský potok (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 52 na zastávku Ríšova'
id: 20190111-d19b96a4
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
