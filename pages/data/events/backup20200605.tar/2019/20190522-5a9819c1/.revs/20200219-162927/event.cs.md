---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-05-22'
end: '2019-05-22'
title: 'Středeční mapový trénink (všichni)'
place: Veselka
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'v lese u horního okraje nad Veselkou'
eventTypeDescription: 'hvězdice - okruhy - okruhy - Hagaby'
map: 'Veselka (1:7 500, ekvidistance 5 m)'
transport: 'autobusem 51 na zastávku Borovník'
id: 20190522-5a9819c1
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
