---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2019-11-15'
end: '2019-11-15'
title: 'noční mapový trénink'
place: Jedovnice
meetTime: '16:00'
meetPlace: 'parkoviště Sedláčkova (naproti Bille), Líšeň, Novolíšeňská'
transport: 'tram: 8 na zastávku Novolíšeňská, potom auty'
startTime: '17:30'
eventTypeDescription: 'krátká trať'
map: Hacker
signups: 'v členské sekci'
template: trenink
date: '2019-11-11'
id: 20191115-e47da21b
terrain: ''
leader: Jenda
note: "Sraz zde: https://en.mapy.cz/s/jedufegape\r\n<br>Nejezděte trolejákem, nabírá obrovské zpoždění!"
gps: '49.31848, 16.74495'
routes:
    -
        name: Dorost
        link: 'http://3drerun.worldofo.com/?id=-632121&type=info'
    -
        name: H
        link: 'http://3drerun.worldofo.com/?id=-632121&type=info'
    -
        name: D
        link: 'http://3drerun.worldofo.com/index.php?id=-632119&type=info'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/index.php?id=-632120&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
