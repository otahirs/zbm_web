---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-04-17'
end: '2019-04-17'
title: 'Středeční mapový trénink (dorost+)'
place: Radostice
meetTime: '16:30'
meetPlace: 'na parkovišti u STK nad konečnou tramvají 6 a 8 ve Starém Lískovci'
eventTypeDescription: okruhy
map: 'Okrouhlík (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 6, 8 na konečnou zastávku Starý Lískovec, smyčka'
id: 20190417-7cd2fd8f
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
