---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2019-11-29'
end: '2019-11-29'
title: 'noční mapový trénink'
place: Uhřice
meetTime: '16:00'
meetPlace: 'zast.: Slatina, sídliště, parkoviště pod točnou'
transport: 'trol: 33'
startTime: '17:00'
eventTypeDescription: 'delší postupy'
map: Ryndovna
signups: 'v členské sekci'
template: trenink
date: '2019-11-11'
id: 20191129-53b9455c
terrain: ''
leader: Jenda
note: ''
gps: '49.05519, 16.94018'
routes:
    -
        name: D15
        link: 'http://3drerun.worldofo.com/index.php?id=-633912&type=info'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/index.php?id=-633911&type=info'
    -
        name: H
        link: 'http://3drerun.worldofo.com/index.php?id=-633910&type=info'
    -
        name: D
        link: 'http://3drerun.worldofo.com/index.php?id=-633908&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
