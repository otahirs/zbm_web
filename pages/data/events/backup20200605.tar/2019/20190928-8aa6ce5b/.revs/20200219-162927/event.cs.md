---
taxonomy:
    skupina: {  }
type: S
start: '2019-09-28'
end: '2019-09-29'
title: 'Soustředění Vysočina'
id: 20190928-8aa6ce5b
template: soustredeni
date: '2019-07-16'
---
