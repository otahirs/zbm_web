---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-08-28'
end: '2019-08-28'
title: 'Středeční mapový trénink (žáci+)'
place: Benešov
meetTime: '16:30'
meetPlace: 'na parkovišti u obchodního domu BILLA v Líšni na Novolíšeňské'
eventTypeDescription: souboje
map: 'Paprč (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 8 na zastávku Novolíšeňská'
id: 20190828-220bb38b
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
