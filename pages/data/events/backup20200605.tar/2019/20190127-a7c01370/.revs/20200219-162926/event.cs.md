---
taxonomy:
    skupina:
        - dorost
type: T
start: '2019-01-27'
end: '2019-01-27'
title: 'Běh s mapou k soutoku Oslavy a Chvojnice'
place: Březník
meetTime: '8:30'
meetPlace: 'u Bohémy'
transport: 'osobními auty'
id: 20190127-a7c01370
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
