---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: pulci1
type: BZL
start: '2019-12-21'
end: '2019-12-21'
title: 'Magnus cup'
place: Juliánov
template: zavod
date: '2019-11-11'
id: 20191221-02455261
meetTime: '10:00'
meetPlace: 'Jůliánov, dle rozpisu'
link: 'https://bzl.zabiny.club/02-magnus'
eventTypeDescription: ''
startTime: '10:30'
map: ''
terrain: ''
transport: ''
leader: ''
note: ''
---
