---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: M
start: '2019-02-22'
end: '2019-02-22'
title: 'noční mapový trénink'
place: Rudice
meetTime: '17:00'
meetPlace: 'na parkovišti u obchodního domu BILLA v Líšni na Novolíšeňské'
eventTypeDescription: Hagaby
map: 'Padouch (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 8 na zastávku Novolíšeňská'
id: 20190222-9a39f03f
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
