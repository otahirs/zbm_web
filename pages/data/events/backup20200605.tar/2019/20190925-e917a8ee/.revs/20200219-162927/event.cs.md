---
taxonomy:
    skupina:
        1: pulci1
        3: zaci1
        4: zaci2
        5: dorost
        6: zabicky
        7: pulci1
        8: zaci1
        9: zaci2
        10: dorost
        11: zabicky
        12: pulci1
        13: zaci1
        14: zaci2
        15: dorost
type: M
start: '2019-09-25'
end: '2019-09-25'
title: 'Středeční mapový trénink (všichni)'
place: Žebětín
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'u okraje lesa mezi Žebětínem a Bystrcí'
eventTypeDescription: 'hvězdice - azimutové hvězdice s okruhy - sudá-lichá - kombotech'
map: 'Pekárna (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 52 na zastávku Kopce'
id: 20190925-e917a8ee
template: trenink
date: '2019-07-16'
startTime: ''
terrain: ''
leader: ''
note: ''
GPS: '16.47702, 49.21183'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
