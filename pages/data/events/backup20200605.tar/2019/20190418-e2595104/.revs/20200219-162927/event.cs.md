---
taxonomy:
    skupina: {  }
type: S
start: '2019-04-18'
end: '2019-04-22'
title: 'Velikonoční soustředění Písek'
place: Písek
id: 20190418-e2595104
template: soustredeni
date: '2019-07-16'
---
