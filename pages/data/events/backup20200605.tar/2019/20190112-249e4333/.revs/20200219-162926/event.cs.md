---
taxonomy:
    skupina:
        - zaci2
        - dorost
type: T
start: '2019-01-12'
end: '2019-01-12'
title: 'Běžecké testy - Lesná = Zhustových 60 minut'
place: Lesná
meetTime: '9:30'
meetPlace: 'u rozvodny nad Lesnou'
transport: 'autobusem 57 na zastávku Rozvodna'
id: 20190112-249e4333
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
