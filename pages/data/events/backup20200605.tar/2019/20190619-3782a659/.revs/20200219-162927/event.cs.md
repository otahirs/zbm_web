---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-06-19'
end: '2019-06-19'
title: 'Středeční mapový trénink (dorost+)'
place: Chlébské
meetTime: '16:30'
meetPlace: 'u konečné tramvaje číslo 1 v Řečkovicích'
eventTypeDescription: 'krátké postupy'
map: 'Chlébské údolí (1:10 000, ekvisitance 5 m)'
transport: 'tramavjí 1 na konečnou zastávku Řečkovice'
id: 20190619-3782a659
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
