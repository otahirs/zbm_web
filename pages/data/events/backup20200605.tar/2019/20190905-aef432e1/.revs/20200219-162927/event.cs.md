---
taxonomy:
    skupina: {  }
type: Z
start: '2019-09-05'
end: '2019-09-06'
title: 'Mistrovství ČR štafet a klubů (PGP)'
id: 20190905-aef432e1
template: zavod
date: '2019-07-16'
---
