---
taxonomy:
    skupina: {  }
type: TABOR
start: '2019-08-17'
end: '2019-08-24'
title: 'Tábor OB 2019'
place: Doksy
id: 20190817-8c753365
template: tabor
date: '2019-07-16'
---
