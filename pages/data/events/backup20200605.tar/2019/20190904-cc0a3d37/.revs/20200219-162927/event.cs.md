---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-09-04'
end: '2019-09-04'
title: 'Středeční mapový trénink (žáci-)'
place: 'Kohoutovice, Myslivna'
meetTime: '16:15'
meetPlace: 'na křižovatce v lese nedaleko hotelu Myslivna'
eventTypeDescription: 'odbočovák - souboje - koridory'
map: 'Myslivna (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 52 na zastávku Šárka'
id: 20190904-cc0a3d37
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
