---
taxonomy:
    skupina: {  }
type: Z
start: '2019-04-06'
end: '2019-04-07'
title: 'Mistrovství Moravy 2019 - klasická trať  (ŽB - Morava) + štafety (AOV)'
id: 20190406-97c37a23
template: zavod
date: '2019-07-16'
---
