---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-28'
end: '2019-06-30'
title: 'Cena střední Moravy (KON)'
place: Kladky
id: 20190628-c3c8eac9
template: zavod
date: '2019-07-16'
---
