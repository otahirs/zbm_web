---
taxonomy:
    skupina: {  }
type: S
start: '2019-06-28'
end: '2019-07-03'
title: 'Soustředění Cena střední Moravy'
place: 'Suchý u Boskovic'
id: 20190628-5fa7f392
template: soustredeni
date: '2019-07-16'
---
