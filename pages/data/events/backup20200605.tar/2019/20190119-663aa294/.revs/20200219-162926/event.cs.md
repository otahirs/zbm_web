---
taxonomy:
    skupina:
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2019-01-19'
end: '2019-01-19'
title: 'Brněnský běžecký pohár (6. závod)'
place: Radostice
meetTime: '9:00'
meetPlace: 'Radostice, sokolovna'
startTime: '10:30 / 11:15'
transport: individuálně
id: 20190119-663aa294
template: akce
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
