---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-10-02'
end: '2019-10-02'
title: 'Středeční mapový trénink (všichni)'
place: Kohoutovice
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'v lese u pomníčku nedaleko ZŠ Pavlovská'
eventTypeDescription: 'štafety (ve dvojicích) - I. úsek štafet - I. úsek štafet - I. úsek štafet'
map: 'Dub Troják (1:10 000, ekvidistance 5 m)'
transport: 'trolejbusem 37 na zastávku Pavlovská'
id: 20191002-3dc0be61
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
