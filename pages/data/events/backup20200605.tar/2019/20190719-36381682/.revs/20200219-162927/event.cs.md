---
taxonomy:
    skupina: {  }
type: Z
start: '2019-07-19'
end: '2019-07-21'
title: 'Grand Prix Silesia (AOP)'
place: Jakartovice
id: 20190719-36381682
template: zavod
date: '2019-07-16'
---
