---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-05-15'
end: '2019-05-15'
title: 'Středeční mapový trénink (dorost+)'
place: 'Blansko, Palava'
meetTime: '16:30'
meetPlace: 'na parkovišti u obchodního domu LIDL na Lesné na Halasově náměstí'
eventTypeDescription: 'sprintové variace'
map: 'Blansko (1:4 000, ekvidistance 2,5 m)'
transport: 'tramvají 9, 11 na zastávku Halasovo náměstí'
id: 20190515-5c443e87
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
