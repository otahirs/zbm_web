---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-01'
end: '2019-06-01'
title: 'ŽB-Morava + Jihomoravská liga - klasická trať (PLU)'
id: 20190601-1bbcab78
template: zavod
date: '2019-07-16'
---
