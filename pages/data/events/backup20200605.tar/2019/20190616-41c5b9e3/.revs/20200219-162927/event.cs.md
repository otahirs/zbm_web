---
taxonomy:
    skupina: {  }
type: Z
start: '2019-06-16'
end: '2019-06-16'
title: 'ŽB-Morava - krátká trať (VBM)'
id: 20190616-41c5b9e3
template: zavod
date: '2019-07-16'
---
