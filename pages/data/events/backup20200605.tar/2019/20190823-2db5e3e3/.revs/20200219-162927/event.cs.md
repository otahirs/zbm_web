---
taxonomy:
    skupina: {  }
type: Z
start: '2019-08-23'
end: '2019-08-25'
title: 'Pěné prázdniny s OB v Českém ráji (TUR)'
place: Kacanovy
id: 20190823-2db5e3e3
template: zavod
date: '2019-07-16'
---
