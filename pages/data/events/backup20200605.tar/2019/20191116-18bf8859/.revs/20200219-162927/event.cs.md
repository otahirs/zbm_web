---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: T
start: '2019-11-16'
end: '2019-11-16'
title: 'Běh s mapou, trénink žáků a výprava pulců'
place: Útěchov
meetTime: '9:30'
meetPlace: 'zastávka MHD: U buku'
transport: 'bus: 57'
template: trenink
date: '2019-11-11'
id: 20191116-18bf8859
eventTypeDescription: ''
startTime: ''
map: 'U buku'
terrain: ''
leader: ''
note: 'Přihlášky v členské sekci'
gps: '49.27636, 16.63033'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
