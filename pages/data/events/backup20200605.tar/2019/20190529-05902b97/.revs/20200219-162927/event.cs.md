---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: M
start: '2019-05-29'
end: '2019-05-29'
title: 'Středeční mapový trénink (všichni)'
place: 'Ochoz u Brna'
meetTime: '16:15 (žáci-) / 16:30 (dorost+)'
meetPlace: 'na parkovišti nad hotelem Velká Klajdovka odkud bude kyvadlová doprava na start tréninku'
eventTypeDescription: 'okruhy - COB - paměťové tandemy - souboje'
map: 'Zadní Hády (1:10 000, ekvidistance 5 m)'
transport: 'autobusem 78 na zastávku Podbělová'
id: 20190529-05902b97
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
