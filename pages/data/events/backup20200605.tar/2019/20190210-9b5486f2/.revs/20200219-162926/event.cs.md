---
taxonomy:
    skupina: {  }
type: S
start: '2019-02-10'
end: '2019-02-17'
title: 'Soustředění Krkonoše - Špindlerův Mlýn'
place: 'Špindlerův Mlýn'
transport: 'tam kombinací vlaku a autobusu, zpátky autobusem, nebo individuální – podrobnosti pro individuální dopravu u Zhusty'
accomodation: 'Chata SK LOB Nová Paka ve Špindlerově Mlýně, těsně pod vrcholem Přední Planina přímo pod lanovou dráhou Svatý Petr – Pláně. Spí se na postelích. Nutno vzít spací pytel.'
food: 'zajištěno od oběda 10. února do oběda 17. února'
note: 'Na chatě je ping-pongový stůl. Sprcha není k dispozici (teplá voda v omezené míře,  v nepřeberném množství). Vezměte si sebou co nejméně věcí. Všechny věci povezeme nahoru lanovkou.'
return: 'v neděli 17. února v 17:46 do Brna na hlavní nádraží. Odjezd ze Špindlerova Mlýna v 13:05'
price: 'předpokládaná cena je 2 500,– Kč (ubytování + stravování),<br> s cestou maximálně 3 000, ,– Kč'
program: 'Podle sněhových podmínek, předpokládáme, že sněhu bude dost. Pokud někdo chcete sjezdovat, vezměte si s sebou i sjezdovky.'
signups: 'do 27. ledna přes členskou sekci. Pokud pojedete individuálně, nezapomeňte to sdělit.'
id: 20190210-9b5486f2
template: soustredeni
date: '2019-07-16'
---
{{page.header.note}}
 Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
