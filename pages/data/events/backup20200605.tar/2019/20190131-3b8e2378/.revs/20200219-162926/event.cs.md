---
taxonomy:
    skupina: {  }
type: S
start: '2019-01-31'
end: '2019-02-03'
title: 'Soustředění Sklené II'
place: 'Sklené u Frayšavy'
meetTime: '16:00'
meetPlace: 've vestibulu hlavního nádraží'
transport: 've čtvrtek 31. ledna v 16:20 vlakem z Brna hl. nádraží (sraz 16:00 ve vestibulu nádraží. Jízdenku zakoupit do stanice Žďár nad Sázavou (R 976). Ve Žďáru přestup na autobus směr Sněžné, odjezd 17:50.'
accomodation: 'Turistická základna DDM Žďár nad Sázavou Sklené – klasické místo našich soustředění. Ubytování na postelích v povlečených peřinách. WC a sprcha na pokoji.'
food: 'plná penze + svačinky. Po celý den bude k dispozici společný čaj.'
note: 'soustředění je určeno především pro pulce, žáky a dorostnce (mají přednost), ostatní do maxima kapacity.'
return: 'v neděli 3. února 15:40 (14:30) vlakem do Brna.'
price: '1 200,– Kč. V ceně je ubytování, doprava a náklady na společné jídlo. Peníze se platí přes oddílový účet a příslušné částky se objeví u každého v členské sekci.'
program: 'lyžování podle sněhových podmínek.'
thingsToTake: 'maratonky a orientky (pokud sníh nebude) nebo lyže (pokud sníh bude), věci co běžně potřebujete, tréninkový deník, hry na dlouhé 4 zimní večery a další dle toho co Vás napadne.'
signups: 'nejpozději do 13. ledna 2018, kapacita 42 osob'
id: 20190131-3b8e2378
template: soustredeni
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
