---
taxonomy:
    skupina: {  }
type: Z
start: '2019-04-13'
end: '2019-04-14'
title: 'Mistrovství ČR v nočním OB + ŽA krátká trať (SHK)'
id: 20190413-7f9be8db
template: zavod
date: '2019-07-16'
---
