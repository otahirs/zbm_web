---
taxonomy:
    skupina:
        - dorost
type: M
start: '2019-09-18'
end: '2019-09-18'
title: 'Středeční mapový trénink (dorost+)'
place: Svinošice
meetTime: '16:30'
meetPlace: 'na parkovišti u obchodního domu LIDL na Lesné na Halasově náměstí'
eventTypeDescription: COB
map: 'Babí lom (1:10 000, ekvidistance 5 m)'
transport: 'tramvají 9, 11 na zastávku Halasovo náměstí'
id: 20190918-215e2ed2
template: trenink
date: '2019-07-16'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
