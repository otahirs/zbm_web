---
taxonomy:
    skupina:
        - dorost
type: T
start: '2019-03-02'
end: '2019-03-02'
title: 'Běh s mapou z Vlčího kopce'
place: Radostice
meetTime: '8:45'
meetPlace: 'na hlavním nádraží (parkoviště u 5. a 6. nástupiště)'
transport: 'vlakem (Brno - Radostice)'
note: 'sraz je v běžeckém oblečení, věci na převlečení si dáme do auta, které pak bude čekat v Kohoutovicích'
id: 20190302-5f9f0058
template: trenink
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
