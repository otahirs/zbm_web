---
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BZL
start: '2019-02-24'
end: '2019-02-24'
title: 'Brněnská zimní liga (4. závod)'
startTime: '14:00'
id: 20190224-adfe7bcc
template: akce
date: '2019-07-16'
---
