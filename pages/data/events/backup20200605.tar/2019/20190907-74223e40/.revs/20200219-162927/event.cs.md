---
taxonomy:
    skupina: {  }
type: Z
start: '2019-09-07'
end: '2019-09-08'
title: 'Český pohár, ŽA, ŽB-Morava - klasická a krátká trať (TZL)'
id: 20190907-74223e40
template: zavod
date: '2019-07-16'
---
