---
taxonomy:
    skupina:
        - dorost
type: L
start: '2019-09-19'
end: '2019-09-19'
title: 'Liga brněnských škol v orientačním běhu (1. kolo)'
place: Kohoutovice
meetTime: '8:00'
meetPlace: 'hřiště u ZŠ Pavlovská'
startTime: '9:30'
doWeOrganize: '1'
note: 'pořadatelé: Zhusta + dorostenci'
id: 20190919-48cd7905
template: akce
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
