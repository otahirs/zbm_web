---
taxonomy:
    skupina:
        - dorost
type: L
start: '2019-06-07'
end: '2019-06-07'
title: 'Liga brněnských škol v orientačním běhu (finále)'
place: Vinohrady
meetTime: '8:00'
meetPlace: 'louka za školou na Bzenecké ulici'
startTime: '9:30'
doWeOrganize: '1'
note: 'pořadatelé: Zhusta + dorostenci'
id: 20190607-86a4056f
template: akce
date: '2019-07-16'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}.
