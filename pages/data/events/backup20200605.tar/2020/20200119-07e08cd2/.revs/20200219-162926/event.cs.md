---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: T
start: '2020-01-19'
end: '2020-01-19'
title: 'S mapou do Brna, výprava pulců'
place: Březina
meetTime: '9:00'
meetPlace: 'Stará Osada (odjezd 9:15)'
transport: 'busem IDS: 201 ze Staré osady do Březiny'
startTime: '9:43'
template: trenink
date: '2020-01-11'
id: 20200119-07e08cd2
eventTypeDescription: ''
map: ''
terrain: ''
leader: 'Andrea, Jenda'
note: "Přijďte včas ať nám autobus neujede.\r\nDorost+: Přijďte v běhacím, na místě bude auto, které převeze převlečení do cíle."
gps: '49.28160, 16.74947'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
