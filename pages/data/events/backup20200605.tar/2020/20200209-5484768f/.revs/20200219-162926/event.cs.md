---
id: 20200209-5484768f
template: zavod
title: 'BZL - O-mikron'
start: '2020-02-09'
end: '2020-02-09'
place: 'Brno - pod Hády'
meetTime: '10:15'
meetPlace: 'https://mapy.cz/s/kurekefane'
link: 'https://oris.orientacnisporty.cz/'
eventTypeDescription: ''
startTime: '10:30'
map: ''
terrain: ''
transport: 'MHD, trolejbudem č. 25 na zastávku Vlčnovská. Odtud je shromaždiště vzdáleno 930 metrů, cesta bude značena.'
leader: ''
note: ''
taxonomy:
    skupina:
        1: pulci1
        2: pulci2
        3: zaci1
        4: zaci2
gps: '49.2108, 16.6695'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
