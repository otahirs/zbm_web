---
id: 20200118-ced56afd
template: zavod
title: 'BZL - Kufrování s medvědem'
start: '2020-01-18'
end: '2020-01-18'
place: Radostice
meetTime: ''
meetPlace: ''
link: 'https://bzl.zabiny.club/05-medved'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: ''
note: ''
gps: '49.1327, 16.4792'
---
