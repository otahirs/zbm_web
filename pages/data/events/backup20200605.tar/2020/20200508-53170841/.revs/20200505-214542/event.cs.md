---
id: 20200508-53170841
template: soustredeni
type: S
title: 'Květen vol. 2'
start: '2020-05-08'
end: '2020-05-10'
place: 'Veselka, Kramolín sever'
meetTime: ''
meetPlace: ''
transport: Vlastní
leader: 'LuF, Pavel R.'
note: "2 mapové tréninky, startovky a mapy budou během středy (nejpozději ve čtvrtek ráno).\r\n\r\n**Mapy ke stažení:**\r\n* Veselka\r\n* Kramolín\r\n \r\nStartovky (časy příjezdů)"
return: ''
price: '0,-'
program: "* Veselka: D - seběhy, DH14 - COB na vrstevnice a azimuty, DH12 - linie, DH10 - COB - [parkování u lesa](https://en.mapy.cz/s/kozamuhevu)\r\n* Kramolín sever - všichni middle - parkování bude upřesněno\r\n\r\nNezapomeňte prosím vyplnit startovky (časy příjezdů).\r\nNa kontrolách budou fábory, pro mladší by měly obsahovat i kód kotroly."
thingsToTake: ''
signups: ''
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
accomodation: ''
food: ''
---
 Doprava {{page.header.transport}}.
