---
taxonomy:
    skupina:
        - dorost
id: 20200409-Race_1415
start: '2020-04-09'
end: '2020-04-09'
title: 'INOV-8 CUP - žebříček A 2020'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5760'
orisid: '5760'
place: ČR
type: Z
template: zavod
date: '2020-03-10'
import:
    type: members
    time: 1583866502
---
Končí přihlášky do žebříčku A na rok 2020.