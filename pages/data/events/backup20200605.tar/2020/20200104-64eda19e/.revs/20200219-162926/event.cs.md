---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2020-01-04'
end: '2020-01-04'
title: 'BBP - Kuřimský kros'
place: 'Kuřim, ZŠ'
meetTime: '9:30'
transport: 'auty dle domluvy'
startTime: '13:30'
template: trenink
date: '2019-12-28'
id: 20200104-64eda19e
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
