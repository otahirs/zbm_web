---
id: 20200301-f0b8a94f
template: zavod
title: 'BZL - Hruška Cup'
start: '2020-03-01'
end: '2020-03-01'
place: 'Brno, ZŠ Vedlejší'
meetTime: '14:00'
meetPlace: 'Brno, ZŠ Vedlejší'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5529'
eventTypeDescription: 'H, D, ZV, HDD'
startTime: '14:00'
map: Bohunice
terrain: Sídliště
transport: MHD
leader: ''
note: ''
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
gps: '49.171, 16.5716'
---
 {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
