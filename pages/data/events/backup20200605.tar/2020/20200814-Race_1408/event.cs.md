---
taxonomy:
    skupina: {  }
id: 20200814-Race_1408
start: '2020-08-14'
end: '2020-08-16'
title: 'Tis 2020'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5829'
orisid: '5829'
place: 'Tis u Blatna'
type: Z
template: zavod
date: '2020-04-23'
import:
    type: members
    time: 1587592801
---
