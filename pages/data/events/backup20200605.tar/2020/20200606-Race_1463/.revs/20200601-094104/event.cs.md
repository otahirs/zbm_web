---
taxonomy:
    skupina:
        1: dorost
id: 20200606-Race_1463
start: '2020-06-06'
end: '2020-06-07'
title: 'TT - Praha'
place: Praha
type: Z
template: zavod
date: '2020-05-25'
import:
    type: members
    time: 1590357602
meetTime: ''
meetPlace: 'bude upřesněno, cíl -> https://mapy.cz/s/babesevobu'
link: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: autem
accomodation: 'Ve stanu, spacák s sebou'
food: 'vlastní, večeře nad ohněm'
leader: 'Miloš v Praze, doprava Jenda'
note: "5-6x TT v Praze\r\nPrvní den budeme mít sraz na Hostivaři #45, Adam by zase mohl udělat automodul. Pak hned přejedeme do Kunraťáku #2 - následovat bude oběd <-> přejezd do Dobřichovic, okouknout naše \"ubytování\" 49.9397322N, 14.3148965E. Odpoledne loupneme trackyho Všenory #24. Večerní program je jasný - mytí v řece a následná grilovačka/opíkačka špekáčků. Umí někdo na kytaru a může jí vzít s sebou? :D\r\n\r\nDalší den začneme na Petříně #21 a ještě dopoledne sjedeme Šárku #5100 teda #37 - tím končí dorostenky a slabší kusy. Tvrďáci ještě vyrazí na Kozí hřbety #30. -> A s kupou bodů hurá domů.\r\n\r\nTak doufám, že nás tam pojede hafo.\r\nBěhu zdar a trailtourařům zvláště.\r\n\r\n/Dým"
gps: '49.93973, 14.31489'
---
{{page.header.note}}
 {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
