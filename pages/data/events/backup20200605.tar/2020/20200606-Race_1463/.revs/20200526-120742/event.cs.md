---
taxonomy:
    skupina:
        - dorost
id: 20200606-Race_1463
start: '2020-06-06'
end: '2020-06-07'
title: 'TT - Praha'
place: Praha
type: Z
template: zavod
date: '2020-05-25'
import:
    type: members
    time: 1590357602
meetTime: ''
meetPlace: 'Brno, hl.n.'
link: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: vlakem
accomodation: 'Ve stanu, spacák s sebou'
food: 'vlastní, večeře nad ohněm'
leader: 'Miloš v Praze, doprava Jenda'
note: '5-6x TT v Praze'
---
