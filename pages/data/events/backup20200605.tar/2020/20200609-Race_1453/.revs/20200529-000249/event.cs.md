---
taxonomy:
    skupina: {  }
id: 20200609-Race_1453
start: '2020-06-09'
end: '2020-06-09'
title: 'Dorost+ - mapový trénink Velká Roudka'
place: 'Velká Roudka'
type: T
note: 'krátká trať'
template: trenink
date: '2020-05-29'
import:
    type: members
    time: 1590703202
---
{{page.header.note}}
