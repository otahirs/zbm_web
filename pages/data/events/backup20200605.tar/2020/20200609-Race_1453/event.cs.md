---
taxonomy:
    skupina:
        - dorost
id: 20200609-Race_1453
start: '2020-06-09'
end: '2020-06-09'
title: 'Dorost+ - mapový trénink Velká Roudka'
place: 'Velká Roudka'
type: T
note: 'krátká trať'
template: trenink
date: '2020-05-29'
import:
    type: members
    time: 1590703202
meetTime: '16:30'
meetPlace: 'Kr. Pole, nádraží'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: auty
leader: Jenda
gps: '49.59605, 16.66019'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
