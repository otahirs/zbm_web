---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: BBP
start: '2020-01-18'
end: '2020-01-18'
title: 'BBP - Radostická nerezová desítka'
place: Radostice
meetTime: '9:30'
transport: 'auty dle domluvy'
startTime: '14:30'
template: trenink
date: '2019-12-28'
id: 20200118-eb31af18
meetPlace: 'Radostice, KD'
eventTypeDescription: ''
map: ''
terrain: ''
leader: ''
note: 'https://www.brnenskybezeckypohar.cz/'
gps: '49.13256, 16.47907'
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
