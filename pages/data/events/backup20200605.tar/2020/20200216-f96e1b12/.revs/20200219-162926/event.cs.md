---
taxonomy:
    skupina:
        1: dorost
type: S
start: '2020-02-16'
end: '2020-02-23'
title: 'Mapové soustředění Portugalsko'
place: 'Aguiar da Beira'
meetTime: '9:00'
meetPlace: 'Brno, hl.n.'
transport: 'Autobusem, letecky'
accomodation: 'Na posteli, je třeba vzít lehký spacák a prostěradlo'
food: 'vaříme si sami'
return: '19:00'
price: '3500 + letenka + jídlo'
program: 'mapové tréninky viz rozpis v pdf'
thingsToTake: 'teplé oblečení, může být od +5 do +25 °C'
signups: ''
template: soustredeni
date: '2020-01-13'
id: 20200216-f96e1b12
leader: Jenda
note: '[Plný rozpis](https://docs.google.com/document/d/1_mfyvCDJcRV-D_cg4dSf6XPP3lkOrR81NqLtq-2blfs/edit?usp=sharing)'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
