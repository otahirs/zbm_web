---
id: 20200105-74a5f3d2
template: trenink
title: 'BZL - Návrat ke Kořenům'
start: '2020-01-05'
end: '2020-01-05'
place: 'Podlesí u Kuřimi, zahrádka hospůdky U Anděla'
meetTime: '9:30'
meetPlace: ''
eventTypeDescription: ''
startTime: '10:00'
map: 'velmi stará'
terrain: ''
transport: 'každý sám'
leader: ''
note: '[Ropis](http://hroudokaps.foxklub.cz/navrat20.htm)'
taxonomy:
    skupina:
        1: dorost
gps: '49.30583, 16.56305'
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
