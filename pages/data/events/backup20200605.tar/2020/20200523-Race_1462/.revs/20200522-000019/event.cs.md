---
taxonomy:
    skupina: {  }
id: 20200523-Race_1462
start: '2020-05-23'
end: '2020-05-23'
title: 'Testovani - Zadní Hády, Dorost +'
place: 'Zadní Hády'
type: Z
template: zavod
date: '2020-05-22'
import:
    type: members
    time: 1590098401
---
