---
taxonomy:
    skupina:
        1: dorost
id: 20200523-Race_1462
start: '2020-05-23'
end: '2020-05-23'
title: 'Testovani - Zadní Hády, Dorost +'
place: 'Zadní Hády'
type: T
template: trenink
date: '2020-05-22'
import:
    type: members
    time: 1590098401
meetTime: '11:00'
meetPlace: 'Naproti lomu Kalcit'
link: ''
eventTypeDescription: 'Délka je limitována časem.'
startTime: '11:15'
map: 'Kalcit, 1: 10 000, e = 5m, stav zima 2020'
terrain: 'Těžký mapově, fyzicky i podložkou.'
transport: 'Když dorazíte na kole, pohlídám ho.'
leader: Jenda
note: 'Intervalový start, SI v air modu. Rozdílné tratě pro D a H'
gps: '49.23024, 16.70108'
results:
    -
        name: 'Výsledky s časy po jednotlivých kolech'
        link: 'https://www.dropbox.com/s/ynns3qpgercc36m/vysledky.txt?dl=0'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
