---
taxonomy:
    skupina:
        - dorost
id: 20201011-Race_1457
start: '2020-10-11'
end: '2020-10-11'
title: 'INOV-8 CUP - žebříček A'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5956'
orisid: '5956'
place: 'Plzeň, Krašovská Aktivity centrum'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
