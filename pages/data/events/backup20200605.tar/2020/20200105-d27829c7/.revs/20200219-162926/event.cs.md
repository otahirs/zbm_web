---
id: 20200105-d27829c7
template: trenink
title: 'Běh s mapou - Pohádka Máje'
start: '2020-01-11'
end: '2020-01-11'
place: Žebětín
meetTime: '9:30'
meetPlace: 'klasicky v Žebětíně (prosím auta parkujte dole ve vesnici!)'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: 'bus: 52, zastávka Ríšova'
leader: ''
note: ''
taxonomy:
    skupina:
        1: dorost
gps: '49.20486, 16.47755'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
