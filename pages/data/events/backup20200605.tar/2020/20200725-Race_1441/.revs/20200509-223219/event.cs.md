---
taxonomy:
    skupina: {  }
id: 20200725-Race_1441
start: '2020-07-25'
end: '2020-08-01'
title: 'Prázdninové soustředění Liberecko'
link: ''
place: 'Karlov (Josefův důl)'
type: S
template: soustredeni
date: '2020-05-09'
import:
    type: members
    time: 1589056321
---
