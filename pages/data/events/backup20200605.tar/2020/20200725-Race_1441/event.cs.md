---
taxonomy:
    skupina:
        - dorost
id: 20200725-Race_1441
start: '2020-07-25'
end: '2020-08-01'
title: 'Prázdninové soustředění Liberecko'
link: ''
place: 'Karlov (Josefův důl)'
type: S
template: soustredeni
date: '2020-05-09'
import:
    type: members
    time: 1589056321
meetTime: '8:00'
meetPlace: 'Nový Lískovec, STK'
transport: 'Osobními auty.'
accomodation: ''
food: ''
leader: 'Jenda, Gába'
note: 'Záleží na vládě...'
return: 'V neděli odpoledne.'
price: '3 950 Kč'
program: 'Rozpis tréninků bude doplněn, předesílám, že závody nejspíš nebudou.'
thingsToTake: 'Věci na OB, plavky. Může být krásně okolo 27°C, ale může nám klidně celý týden pršet a být okolo 15°C, připravte se na to prosím.'
signups: ''
gps: '50.78059, 15.1992'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
