---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-02-28'
end: '2020-02-28'
title: 'noční mapový trénink'
place: Přeckov
gps: '49.27841, 15.91716'
meetTime: '16:45'
meetPlace: 'STK Nový Lískovec'
transport: 'tram: 6, 8, Nový Lískovec'
startTime: '18:15'
eventTypeDescription: 'Krátká trať'
map: Kuchyňka
signups: 'V členské sekci'
template: trenink
date: '2020-01-13'
id: 20200214-19c395e6
terrain: ''
leader: Jenda
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
