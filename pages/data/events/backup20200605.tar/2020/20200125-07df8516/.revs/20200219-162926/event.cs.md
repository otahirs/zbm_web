---
id: 20200125-07df8516
template: zavod
title: 'BZL - Hromniční trápení'
start: '2020-01-25'
end: '2020-01-25'
place: 'DDM, Údolní 2, Blansko'
meetTime: '9:30'
meetPlace: ''
link: 'https://oris.orientacnisporty.cz/Zavod?id=5784'
eventTypeDescription: ''
startTime: '10:30'
map: 'Čertovka 1:5000 , leden 2016, interval vrstevnic 2,5 m'
terrain: 'Občanská zástavba, sídliště, park, kousek lesa'
transport: ''
leader: ''
note: ''
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: pulci1
---
* **sraz**: {{page.header.meetTime}}
