---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: S
start: '2020-03-04'
end: '2020-03-08'
title: 'Slovinsko, Lipica Open'
place: Ankaran
gps: '49.16353, 16.59981'
meetTime: '15:00'
meetPlace: 'Brno, Vídeňská, parkoviště u pekárny'
transport: Auty
accomodation: 'na posteli'
food: polopenze
return: '21:00'
price: '4000'
program: "* středa: odjezd do Slovinska\r\n* čtvrtek: \r\n\t* seznamovací trénink (Vilenica)\r\n\t* COB (Vilenica)\r\n* pátek: \r\n * sprint (Izola)\r\n * věšák-sběrák (Pliskovica)\r\n* sobota a neděle - účast na závodech Lipica Open"
thingsToTake: 'Věci na běhání (teplota v okolí Terstu v tomto období je okolo 15 až 20°C přes den, v noci méně a loni bylo chladněji), plavky (na ubyování je bazén se slanou vodou).'
signups: ''
template: soustredeni
date: '2020-01-13'
id: 20200304-3922bb04
leader: 'Jenda, LuF'
note: "[Web závodů](https://www.lipicaopen.com/)\r\nPojištění nezařizujeme, do Itálie nepojedeme."
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
