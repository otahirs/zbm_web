---
id: 20200530-a650db66
template: zavod
type: Z
title: 'https://oris.ori3. Jihomoravská letní liga'
start: '2020-05-30'
end: '2020-05-30'
place: 'Zamilovaný hájek'
meetTime: ''
meetPlace: ''
link: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: individuální
leader: ''
note: "https://oris.orientacnisporty.cz/PrehledPrihlasenych?id=5977&mode=clubs#205\r\nPřihlášky do 27.5.2020: napsat email na prihlasky"
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
---
{{page.header.note}}
 Doprava {{page.header.transport}}.
