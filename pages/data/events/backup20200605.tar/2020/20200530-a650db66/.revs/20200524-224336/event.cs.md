---
id: 20200530-a650db66
template: zavod
type: Z
title: '3. Jihomoravská letní liga'
start: '2020-05-30'
end: '2020-05-30'
place: 'Zamilovaný hájek'
meetTime: ''
meetPlace: ''
link: 'https://oris.orientacnisporty.cz/PrehledPrihlasenych?id=5977&mode=clubs#205'
eventTypeDescription: 'D12     D14     D16     D18     D21     D35     D45     D55     H12     H14     H21     H35     H45     H55     HD10'
startTime: ''
map: ''
terrain: ''
transport: individuální
leader: ''
note: "https://oris.orientacnisporty.cz/PrehledPrihlasenych?id=5977&mode=clubs#205\r\nPřihlášky do 27.5.2020: napsat email na prihlasky (Drbčovi)\r\nOmezený počet přihlášek, závodníků: 295"
taxonomy:
    skupina:
        2: zaci1
        3: zaci2
---
{{page.header.note}}
 Doprava {{page.header.transport}}.
