---
id: 20200527-ecea4d1f
template: trenink
type: M
title: 'Zadní hády'
start: '2020-05-27'
end: '2020-05-27'
place: 'zastávka Na spáleništi'
meetTime: '16:00'
meetPlace: 'Velká Klajdovka'
eventTypeDescription: "A - okruhy\t\r\nB - COB\r\nC - okruhy"
startTime: '16:30'
map: 'Zadní Hády'
terrain: ''
transport: "MHD:\r\n1. na zastávku Velká Klajdovka (Stará osada 15:45, Autobus 201 - Velká Klajdovka,15:55)\r\nnebo\r\n2. na zastávku Podbělová a odsud pěšky na parkoviště za Velkou Klajdovkou (Česká 15:10,Tramvaj 12 - Dělnický dům, 15:34, Autobus 55 - Podbělová, 15:46)\r\nZ parkoviště za Velkou Klajdovkou bude organizován odvoz auty na místo tréninku"
leader: ''
note: "**Přibližovací srazy** \r\n15:15 - Parkoviště u Billy u zastávky Přívrat (Lenka - 737 353 537)\r\n15:30 - Halasovo náměstí (Alena - 605 440 445)\r\nDoprava bude tentokrát osobními auty. Kontaktujte nás v nejpozději do úterního večera v případě, že plánujete využít společnou dopravu nebo nabízíte volná místa ve vlastním vozidle."
taxonomy:
    skupina:
        1: pulci1
        2: pulci2
        3: zaci1
        4: zaci2
        5: zabicky
gps: '49.24384, 16.71394'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
