---
id: 20200527-ecea4d1f
template: trenink
type: M
title: 'Zadní hády'
start: '2020-05-27'
end: '2020-05-27'
place: 'zastávka Na spáleništi'
meetTime: '16:00'
meetPlace: 'Velká Klajdovka'
eventTypeDescription: "A - okruhy\t\r\nB - COB\r\nC - okruhy"
startTime: '16:30'
map: 'Zadní Hády'
terrain: ''
transport: "MHD:\r\n1. na zastávku Velká Klajdovka\r\nnebo\r\n2. na zastávku Podbělová a odsud pěšky na parkoviště za Velkou Klajdovkou\r\nZ parkoviště za Velkou Klajdovkou bude organizován odvoz auty na místo tréninku"
leader: ''
note: ''
taxonomy:
    skupina:
        1: pulci1
        2: pulci2
        3: zaci1
        4: zaci2
        5: zabicky
gps: '49.24384, 16.71394'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
