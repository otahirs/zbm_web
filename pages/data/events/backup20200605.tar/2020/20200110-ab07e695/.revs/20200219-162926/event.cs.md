---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-01-10'
end: '2020-01-10'
title: 'noční mapový trénink'
place: Březina
meetTime: '16:30'
meetPlace: 'parkoviště naproti Bille (jako minule), Líšeň, Novolíšeňská'
transport: 'tram: 8'
startTime: '17:30'
eventTypeDescription: 'Krátká trať'
map: 'U Coufalů'
template: trenink
date: '2019-12-28'
id: 20200110-ab07e695
terrain: krásný
leader: Jenda
note: "Jeďte šalinou, ostatní MHD bude stát v koloně.\r\nSraz je [zde](https://en.mapy.cz/s/cacajojavo)"
routes:
    -
        name: H
        link: 'http://3drerun.worldofo.com/?id=-638845&type=info'
    -
        name: D
        link: 'http://3drerun.worldofo.com/?id=-638844&type=info'
    -
        name: MEZI
        link: 'http://3drerun.worldofo.com/?id=-638843&type=info'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/?id=-638842&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
