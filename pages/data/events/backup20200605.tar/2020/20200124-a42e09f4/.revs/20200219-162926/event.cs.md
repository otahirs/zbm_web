---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-01-24'
end: '2020-01-24'
title: 'noční mapový trénink'
place: Ochoz
gps: '49.24386, 16.71303'
meetTime: '16:30'
meetPlace: 'parkoviště naproti Bille, Líšeň, Novolíšeňská'
transport: 'tram 8'
startTime: '17:00'
eventTypeDescription: 'Krátká trať'
map: 'Zadní Hády'
template: trenink
date: '2020-01-11'
id: 20200124-a42e09f4
terrain: ''
leader: Jenda
note: '[Místo srazu](https://en.mapy.cz/s/cacajojavo)'
routes:
    -
        name: H
        link: '3drerun.worldofo.com/index.php?id=-16759458&type=info&fbclid=IwAR1GASB9VBH53-Egx2UbE3QMqvITz-1CGPodTOJiXUEYoVaBoJBan385SnQ'
    -
        name: D
        link: 'http://3drerun.worldofo.com/index.php?id=-16759459&type=info'
    -
        name: MEZI
        link: 'http://3drerun.worldofo.com/index.php?id=-16759460&type=info'
    -
        name: Linie
        link: 'http://3drerun.worldofo.com/index.php?id=-16759455&type=info'
results:
    -
        name: 'WinSplits - všechny kategorie'
        link: 'http://obasen.orientering.se/winsplits/online/en/default.asp?page=classes&databaseId=67841&ct=true'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
