---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: BBP
start: '2020-01-25'
end: '2020-01-25'
title: 'BBP - Rájecká desítka'
place: 'Rájec, Gymnázium'
meetTime: ''
transport: 'auty, domlouvejte se mezi sebou, nebo pište na skupinu!'
startTime: ''
template: trenink
date: '2020-01-11'
id: 20200125-38c1687f
meetPlace: ''
eventTypeDescription: ''
map: ''
terrain: ''
leader: ''
note: 'https://www.brnenskybezeckypohar.cz/'
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
