---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-02-07'
end: '2020-02-07'
title: 'noční mapový trénink'
place: Mohelno
meetTime: '16:30'
meetPlace: 'STK Nový Lískovec'
transport: 'tram: 6, 8, Nový Lískovec'
startTime: '18:00'
eventTypeDescription: 'Hagaby, hromadný start'
map: Babylon
signups: 'V členské sekci'
template: trenink
date: '2020-01-13'
id: 20200207-1c24cf39
terrain: ''
leader: ''
note: ''
gps: '49.10988, 16.17636'
routes:
    -
        name: H
        link: 'http://3drerun.worldofo.com/index.php?id=-16761605&type=info'
    -
        name: D
        link: 'http://3drerun.worldofo.com/index.php?id=-16761606&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
