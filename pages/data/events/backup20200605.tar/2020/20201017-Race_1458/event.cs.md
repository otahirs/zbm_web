---
taxonomy:
    skupina:
        - dorost
        - zaci2
        - zaci1
id: 20201017-Race_1458
start: '2020-10-17'
end: '2020-10-17'
title: 'Mistrovství ČR klubů'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5184'
orisid: '5184'
place: 'Cejle – Horní Hutě'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
