---
id: 20200424-70565d00
template: trenink
type: M
title: 'Mapový trénink'
start: '2020-04-24'
end: '2020-04-26'
place: Jedovnice
meetTime: ''
meetPlace: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: 'Jenda, Pavel Rotek, LuF'
note: "* vytiskněte si mapy jako obvykle (moc ji před startem nezkoumejte, ať si nekazíte zážitek)\r\n* na kontrolách budou fábory z mlíka, kontroly pro DH10 - 12 budou mít na fáboru napsané číslo\r\n* samozřejmostí je [tabulka příjezdů](https://docs.google.com/spreadsheets/d/15Sxrpu_Bl4CybUxhZZuW-BrKU4RY5tDV-vmpfpRhMDI/edit#gid=0)"
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
gps: '49.33314, 16.76533'
---
{{page.header.note}}
