---
id: 20200424-70565d00
template: trenink
type: M
title: 'Mapový trénink'
start: '2020-04-24'
end: '2020-04-26'
place: Sentice
meetTime: ''
meetPlace: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: 'Jenda, Pavel Rotek, LuF'
note: "* [vytiskněte si mapy jako obvykle](https://www.dropbox.com/sh/2yrppjxp4xnf30f/AAByBwPZadZLPYNkIXsh6f6Ua?dl=0) (Dorost a starší mrkne tentokrát, co je čeká aby tušil)\r\n* do mobilu si stáhněte pdf s cestou na start, abyste trefili (u auta si to snadno zapamatujete, takže netřeba tisknout)\r\n* na kontrolách budou fábory z mlíka, kontroly pro DH10 - 12 budou mít na fáboru napsané číslo\r\n* samozřejmostí je [tabulka příjezdů](https://docs.google.com/spreadsheets/d/15Sxrpu_Bl4CybUxhZZuW-BrKU4RY5tDV-vmpfpRhMDI/edit#gid=0)"
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
gps: '49.30597, 16.44486'
accomodation: ''
food: ''
---
* [vytiskněte si mapy jako obvykle](https://www.dropbox.com/sh/2yrppjxp4xnf30f/AAByBwPZadZLPYNkIXsh6f6Ua)
* do mobilu si stáhněte pdf s cestou na start
* samozřejmostí je [tabulka příjezdů](https://docs.google.com/spreadsheets/d/15Sxrpu\_Bl4CybUxhZZuW-BrKU4RY5tDV-vmpfpRhMDI/edit#gid=0)