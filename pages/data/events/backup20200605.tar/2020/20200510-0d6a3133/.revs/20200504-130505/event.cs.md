---
id: 20200510-0d6a3133
template: trenink
type: T
title: 'Vytrvalost - TT Znojmo'
start: '2020-05-10'
end: '2020-05-10'
place: Znojmo
meetTime: '10:00'
meetPlace: 'viz GPS, odjezd auty dle bydliště'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: 'auty (řeší Adam Urbánek)'
leader: 'Drbča, Miloš'
note: "[Link na trať](http://www.trailtour.cz/2020/etapy-cz/cz-etapa41-znojmo-podyji/)\r\nMapy vytiskneme, kdo bude potřebovat, dejte prosím vědět Jendovi."
taxonomy:
    skupina:
        - dorost
gps: '48.86092, 16.03059'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
