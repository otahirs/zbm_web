---
id: 20200112-3d2f9361
template: zavod
title: 'BZL - Onos Cup'
start: '2020-01-12'
end: '2020-01-12'
place: 'Brno - Žabovřesky'
meetTime: ''
meetPlace: 'hala Rosnička'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5520'
eventTypeDescription: ''
startTime: '14:00'
map: Rosnička
terrain: ''
transport: "tram 1: zast. Bráfova\r\ntram 3, 11: zast"
leader: ''
note: ''
gps: '49.20673, 16.57685'
taxonomy:
    skupina:
        - zabicky
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
---
 {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
