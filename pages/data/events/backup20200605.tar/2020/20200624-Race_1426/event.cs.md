---
taxonomy:
    skupina:
        - dorost
        - zaci2
        - zaci1
        - pulci2
        - pulci1
        - zabicky
id: 20200624-Race_1426
start: '2020-06-24'
end: '2020-06-24'
title: 'Jml: Mistrovství oblasti ve štafetách'
link: 'http://oris.orientacnisporty.cz/Zavod?id=5521'
place: Mokrá-Horákov
type: Z
template: zavod
date: '2020-05-28'
import:
    type: members
    time: 1590616801
---
