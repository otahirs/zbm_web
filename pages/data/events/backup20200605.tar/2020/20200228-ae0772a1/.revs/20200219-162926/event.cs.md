---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-02-14'
end: '2020-02-14'
title: 'noční mapový trénink'
place: Kuničky
meetTime: '16:30'
meetPlace: 'Lidl, Halasovo náměstí'
transport: 'tram: 9, 11'
startTime: '18:45'
eventTypeDescription: 'Hromadný s rozdělovací metodou'
map: Trhůvka
template: trenink
date: '2020-01-13'
id: 20200228-ae0772a1
terrain: ''
leader: Standa
note: ''
routes:
    -
        name: D
        link: 'http://3drerun.worldofo.com/?id=-16762148&type=info'
    -
        name: H
        link: 'http://3drerun.worldofo.com/?id=-16762157&type=info'
    -
        name: HDD
        link: 'http://3drerun.worldofo.com/?id=-16762161&type=info'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
