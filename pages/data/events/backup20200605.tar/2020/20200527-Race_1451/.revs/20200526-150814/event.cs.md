---
taxonomy:
    skupina:
        1: dorost
id: 20200527-Race_1451
start: '2020-05-27'
end: '2020-05-27'
title: 'Dorost+ - mapový trénink Kuničky'
link: ''
place: Kuničky
type: T
note: 'První úsek štafet'
template: trenink
date: '2020-05-15'
import:
    type: members
    time: 1589493601
meetTime: '16.30'
meetPlace: 'Lesná, parkoviště u Lidlu'
eventTypeDescription: ''
startTime: '17.30'
map: ''
terrain: ''
transport: Auty
leader: 'Jenda, doprava Adam U.'
gps: '49.43382, 16.68375'
---
{{page.header.note}}
