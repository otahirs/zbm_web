---
taxonomy:
    skupina:
        - dorost
id: 20200527-Race_1451
start: '2020-05-27'
end: '2020-05-27'
title: 'Dorost+ - mapový trénink Kuničky'
link: ''
place: Kuničky
type: T
note: 'První úsek štafet'
template: trenink
date: '2020-05-15'
import:
    type: members
    time: 1589493601
meetTime: ''
meetPlace: ''
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: ''
leader: ''
---
{{page.header.note}}
