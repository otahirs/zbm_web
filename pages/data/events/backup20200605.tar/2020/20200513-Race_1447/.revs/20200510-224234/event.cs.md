---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
id: 20200513-Race_1447
start: '2020-05-13'
end: '2020-05-13'
title: 'Žákovský mapový trénink, Vytrvalost D+'
link: ''
place: 'Útěchov, U buku'
type: T
template: trenink
date: '2020-05-10'
import:
    type: members
    time: 1589137402
meetTime: '16:00'
meetPlace: 'dle mapy'
eventTypeDescription: "A,B,C\r\nVytrvalost pro D+ (mapy budou k dispozici po dobu trvání tréninku žáků)"
startTime: '16:15'
map: 'Zavíravá 525'
terrain: ''
transport: 'vlastní, MHD'
leader: ''
note: ''
gps: '49.27719, 16.63029'
---
