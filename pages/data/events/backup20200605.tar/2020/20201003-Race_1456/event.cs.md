---
taxonomy:
    skupina:
        - dorost
id: 20201003-Race_1456
start: '2020-10-03'
end: '2020-10-03'
title: 'MČR na krátké trati'
link: 'https://oris.orientacnisporty.cz/Zavod?id=4915'
orisid: '4915'
place: 'Kunratice u České Kamenice,'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
