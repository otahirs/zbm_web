---
taxonomy:
    skupina:
        - dorost
id: 20201010-Race_1380
start: '2020-10-10'
end: '2020-10-10'
title: 'MČR nočním'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5955'
orisid: '5955'
place: 'Plzeň, Krašovská Aktivity centrum'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
