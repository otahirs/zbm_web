---
taxonomy:
    skupina:
        1: dorost
id: 20200603-Race_1452
start: '2020-06-03'
end: '2020-06-03'
title: 'Dorost+ - mapový trénink Valchov'
link: ''
place: Valchov
type: T
note: 'neúpná mapa -> buzola'
template: trenink
date: '2020-05-15'
import:
    type: members
    time: 1589493601
meetTime: '16:30'
meetPlace: 'Kr. Pole, nádraží (parkoviště pod mostem)'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: auty
leader: 'Jenda, doprava Adam Urbánek'
gps: '49.47294, 16.72345'
---
{{page.header.note}}
