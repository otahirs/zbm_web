---
taxonomy:
    skupina:
        1: dorost
id: 20200603-Race_1452
start: '2020-06-02'
end: '2020-06-02'
title: 'Dorost+ - mapový trénink Žďárná'
link: ''
place: Žďárná
type: T
note: 'neúplná mapa -> buzola'
template: trenink
date: '2020-05-15'
import:
    type: members
    time: 1589493601
meetTime: '16:30'
meetPlace: 'Kr. Pole, nádraží (parkoviště pod mostem)'
eventTypeDescription: ''
startTime: ''
map: ''
terrain: ''
transport: auty
leader: 'Jenda, doprava Adam Urbánek'
gps: '49.46948, 16.74383'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
