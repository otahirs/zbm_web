---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: S
start: '2020-01-30'
end: '2020-02-02'
title: 'Soustředění Vysočina'
place: Sklené
gps: '49.61037, 16.00859'
meetTime: '16:00'
meetPlace: 'Brno, hlavní nádraží'
transport: 'vlakem, zavazadla autem'
leader: Andrea
accomodation: 'Na posteli'
food: 'od páteční snídaně'
return: '2.2. 17:40 na hlavní nádraží'
price: '1200'
program: 'Běh nebo lyže'
thingsToTake: 'maratonky, orientky a lyže (pokud bude sníh), hry  na večer'
signups: 'v členské sekci'
template: soustredeni
date: '2020-01-13'
id: 20200130-8163ab59
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
