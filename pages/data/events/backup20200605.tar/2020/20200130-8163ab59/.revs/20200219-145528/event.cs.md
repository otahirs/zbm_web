---
id: 20200130-8163ab59
template: soustredeni
title: 'Soustředění Vysočina'
start: '2020-01-30'
end: '2020-02-02'
place: Sklené
meetTime: '16:00'
meetPlace: 'Brno, hlavní nádraží'
transport: 'vlakem, zavazadla autem'
accomodation: 'Na posteli'
food: 'od páteční snídaně'
leader: Andrea
note: ''
return: '2.2. 17:40 na hlavní nádraží'
price: '1200'
program: 'Běh nebo lyže'
thingsToTake: 'maratonky, orientky a lyže (pokud bude sníh), hry  na večer'
signups: ''
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
gps: '49.61037, 16.00859'
---

* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
* **ubytování**: {{page.header.accomodation}}
* **strava**: {{page.header.food}}
