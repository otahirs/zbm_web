---
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: M
start: '2020-02-29'
end: '2020-02-29'
title: 'Mapový výjezd - Šaštín (2 tréninky)'
place: Šaštín
meetTime: '8:00'
meetPlace: 'Dornnych, parkoviště u Lidlu'
transport: Auty
eventTypeDescription: 'vrstevnicovka, buzola'
map: Šaštín
template: trenink
date: '2020-01-13'
id: 20200229-3cd89343
startTime: ''
terrain: ''
leader: 'Jenda, LuF'
note: 'Sraz [zde](https://mapy.cz/s/nabomekoza)'
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
