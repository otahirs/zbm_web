---
taxonomy:
    skupina:
        - dorost
id: 20201031-Race_1460
start: '2020-10-31'
end: '2020-10-31'
title: 'INOV-8 CUP - žebříček A - krátká trať'
link: 'https://oris.orientacnisporty.cz/Zavod?id=4916'
orisid: '4916'
place: 'Ždírec, louka v SZ cípu obce'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
