---
taxonomy:
    skupina:
        1: dorost
id: 20200426-Race_1439
start: '2020-04-26'
end: '2020-04-26'
title: 'Bezkontaktní testování'
place: 'Brno, Líšeň'
type: M
template: trenink
date: '2020-04-21'
import:
    type: members
    time: 1587592801
meetTime: '10:00'
meetPlace: 'U lomu Kalcit'
eventTypeDescription: 'Délka je limitována časem.'
startTime: '10:15'
map: 'Kalcit, 1: 10 000, e = 5m, stav zima 2020'
terrain: 'Těžký mapově, fyzicky i podložkou.'
transport: 'Když dorazíte na kole, pohlídám ho.'
leader: Jenda
note: "Intervalový start, SI v air modu. Rozdílné tratě pro D a H, intervaly 5 minut\r\n\r\nUrčeno pro dorostence  a případně i eliťáky ZBM (aby nás nebylo moc). Pokud byste mohli jen odpoledne, napište to do přihlášky v členské sekci."
gps: '49.23024, 16.70108'
results:
    -
        name: Výsledky
        link: 'https://docs.google.com/spreadsheets/d/1xO6e_kV6YGVTunUQKD3f5vAyD_RicK7UKbNI2yZbVlo/edit#gid=0'
    -
        name: Mezičasy
        link: 'https://drive.google.com/file/d/1-1iKsXDQN-3ClS2AWQ7qHA1PcPmT_tQS/view?usp=sharing'
---
{{page.header.note}}
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
