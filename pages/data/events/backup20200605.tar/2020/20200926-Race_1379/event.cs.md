---
taxonomy:
    skupina:
        - dorost
        - zaci2
        - zaci1
id: 20200926-Race_1379
start: '2020-09-26'
end: '2020-09-26'
title: 'Mistrovství ČR štafet'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5183'
orisid: '5183'
place: 'Jakubčovice '
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
