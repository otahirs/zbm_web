---
id: 20200501-6396471e
template: soustredeni
type: S
title: 'Květnové mapové soustředění'
start: '2020-05-01'
end: '2020-05-03'
place: 'Brno - Kohoutovice, Kanice/Řícmanice, Radostice'
meetTime: ''
meetPlace: 'viz program'
transport: vlastní
leader: 'Andrea, Steeve, LuF, Pavel R.'
note: ''
return: ''
price: '0,-'
program: "* Dub Troják - kombotech - [parkování u školy](https://en.mapy.cz/s/fazunuzufo)\n* Prosba lesa - postupy na volbu - [parkování u lesa](https://mapy.cz/s/kadelusuje)\n* Radostice - DH14, D+ vrstevnice, DH10, DH12 COB - [parkování podél silnice](https://en.mapy.cz/s/fuzucucetu)\n\nNezapomeňte prosím vyplnit <A HREF=\"https://drive.google.com/open?id=1DSpsn0WUvZmqozhVv2EDRuVJgzdiq3WeIfrirQFyqU4\">startovky (časy příjezdů)</A>\nNa kontrolách budou fábory, pro mladší by měly obsahovat i kód kotroly."
thingsToTake: ''
signups: ''
accomodation: ''
food: ''
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
---
{{page.header.note}}
 Doprava {{page.header.transport}}.
