---
taxonomy:
    skupina:
        1: dorost
        2: zaci2
type: M
start: '2020-03-13'
end: '2020-03-13'
title: 'noční mapový trénink'
place: Soběšice
gps: '49.24767, 16.60977'
meetTime: '17:30'
meetPlace: 'zast.: Útěchovská'
transport: 'bus: 43'
startTime: '18:00'
eventTypeDescription: '1. úsek štafet, stmívání'
map: 'Zamilovaný Háj'
template: trenink
date: '2020-01-13'
id: 20200313-ab09bf24
terrain: ''
leader: ''
note: ''
---
* **sraz**: {{page.header.meetTime}} {{page.header.meetPlace}}. Doprava {{page.header.transport}}.
