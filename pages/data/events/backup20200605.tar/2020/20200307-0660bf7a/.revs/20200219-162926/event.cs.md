---
taxonomy:
    skupina:
        - pulci1
        - pulci2
        - zaci1
        - zaci2
        - dorost
type: BBP
start: '2020-03-07'
end: '2020-03-07'
title: 'BBP - Modřický pohár'
place: 'Modřice, ZŠ Benešova'
meetTime: '9:30'
transport: 'auty dle domluvy'
startTime: '16:30'
template: trenink
date: '2020-01-13'
id: 20200307-0660bf7a
---
* **sraz**: {{page.header.meetTime}} Doprava {{page.header.transport}}.
