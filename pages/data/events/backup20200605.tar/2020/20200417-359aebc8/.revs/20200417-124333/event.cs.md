---
id: 20200417-359aebc8
template: trenink
title: 'Mapový trénink Ivančice'
start: '2020-04-17'
end: '2020-04-19'
place: Ivančice
meetTime: ''
meetPlace: ''
eventTypeDescription: 'DH10, DH12, DH14, long, short'
startTime: ''
map: Réna
terrain: ''
transport: vlastní
leader: Jenda
note: "* [vytiskněte si mapy jako obvykle](https://drive.google.com/open?id=15wl4BiluTLqKut2rZlLA-PO6TtkyUb2g) (moc ji před startem nezkoumejte, ať si nekazíte zážitek)\r\n*  na kontrolách budou fábory z mlíka, kontroly pro DH10 - 12 budou mít na fáboru napsané číslo\r\n* samozřejmostí je [tabulka příjezdů](https://docs.google.com/spreadsheets/d/1ecvPot9awlVRqocwwv2TwAj5EK9bhjgdxMSXoasUthM/edit#gid=0)"
taxonomy:
    skupina:
        1: pulci2
        2: zaci1
        3: zaci2
        4: dorost
        5: pulci1
type: M
accomodation: ''
food: ''
gps: '49.09841, 16.38772'
---
[vytiskněte si mapy jako obvykle](https://drive.google.com/open?id=15wl4BiluTLqKut2rZlLA-PO6TtkyUb2g) (moc ji před startem nezkoumejte, ať si nekazíte zážitek) 
* na kontrolách budou fábory z mlíka, kontroly pro DH10 - 12 budou mít na fáboru napsané číslo
* samozřejmostí je [tabulka příjezdů](https://docs.google.com/spreadsheets/d/1ecvPot9awlVRqocwwv2TwAj5EK9bhjgdxMSXoasUthM/edit#gid=0)

Doprava vlastní.