---
taxonomy:
    skupina:
        - dorost
id: 20201018-Race_1459
start: '2020-10-18'
end: '2020-10-18'
title: 'Mistrovství ČR oblastních výběrů žactva'
link: 'https://oris.orientacnisporty.cz/Zavod?id=5957'
orisid: '5957'
place: 'Cejle – Horní Hutě'
type: Z
template: zavod
date: '2020-05-21'
import:
    type: members
    time: 1590012001
---
